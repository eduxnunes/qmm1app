import tkinter as tk
from tkinter import ttk, messagebox
from openpyxl import load_workbook

def run(db_path):
    def load_options():
        options_dict = {header: set() for header in headers}
        for row in ws.iter_rows(min_row=2, values_only=True):
            for i, header in enumerate(headers):
                value = row[i]
                if value:
                    options_dict[header].add(value)
        return {k: sorted(list(v)) for k, v in options_dict.items()}

    def refresh_all_lists():
        for header in headers:
            lists[header].delete(0, tk.END)
            for item in options_data[header]:
                lists[header].insert(tk.END, item)

    def add_option(header):
        value = entries[header].get().strip()
        if not value:
            return
        if value in options_data[header]:
            messagebox.showwarning("Aviso", f"'{value}' já existe em '{header}'.")
            return
        options_data[header].append(value)
        options_data[header].sort()
        update_excel()
        refresh_all_lists()
        entries[header].delete(0, tk.END)

    def delete_option(header):
        selection = lists[header].curselection()
        if not selection:
            return
        value = lists[header].get(selection[0])
        options_data[header].remove(value)
        update_excel()
        refresh_all_lists()

    def update_excel():
        for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
            for cell in row:
                cell.value = None
        for i in range(max(len(v) for v in options_data.values())):
            for col, header in enumerate(headers):
                val_list = options_data[header]
                if i < len(val_list):
                    ws.cell(row=2+i, column=col+1, value=val_list[i])
        wb.save(db_path)

    wb = load_workbook(db_path)
    ws = wb["Options"]
    headers = [cell.value for cell in ws[1]]
    options_data = load_options()

    window = tk.Toplevel()
    window.title("Gerir Opções")
    window.geometry("800x300")

    frame = tk.Frame(window)
    frame.pack(padx=10, pady=10, fill='both', expand=True)

    lists = {}
    entries = {}

    for i, header in enumerate(headers):
        col_frame = tk.Frame(frame)
        col_frame.grid(row=0, column=i, padx=10, pady=5)

        tk.Label(col_frame, text=header, font=("Arial", 10, "bold")).pack()
        listbox = tk.Listbox(col_frame, height=8, width=20)
        listbox.pack()
        lists[header] = listbox

        entry = tk.Entry(col_frame, width=20)
        entry.pack(pady=2)
        entries[header] = entry

        tk.Button(col_frame, text="Adicionar", command=lambda h=header: add_option(h)).pack(pady=2)
        tk.Button(col_frame, text="Apagar", command=lambda h=header: delete_option(h)).pack(pady=2)

    refresh_all_lists()
    window.mainloop()