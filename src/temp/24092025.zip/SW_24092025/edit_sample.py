import tkinter as tk
from tkinter import ttk, messagebox
from openpyxl import load_workbook
import re
from datetime import datetime
import os
import shutil
from tkcalendar import DateEntry

class SampleEditor:
    BASE_FOLDER_PATH = "H:/QMM/QMM1/02_ISIR/1. ISIR_A-TEST_Tracker/Test_Data"
    # TTNR_REGEX = r"^\d-\d{3}-\d{3}-\d{3}$"  <-- REMOVIDO!

    def __init__(self, db_path, current_user, initial_sample_id=None):
        self.db_path = db_path
        self.current_user = current_user
        self.initial_sample_id = initial_sample_id

        try:
            self.wb = load_workbook(db_path)
            self.data_ws = self.wb["Data"]
            self.options_ws = self.wb["Options"]
        except FileNotFoundError:
            messagebox.showerror("Error", f"Database file not found at {db_path}")
            return
        except KeyError as e:
            messagebox.showerror("Error", f"Required sheet not found in workbook: {e}")
            return
        except Exception as e:
            messagebox.showerror("Error", f"Error loading workbook: {e}")
            return

        self.data_headers = [cell.value for cell in self.data_ws[1]]
        self.options_headers = [cell.value for cell in self.options_ws[1]]
        self.options = self._get_options_dict()
        self.row_to_edit_data = None
        self.row_index_in_excel = None
        self.widgets = {}
        
        self.original_ttnrs_set = set()
        self.current_sample_id = None

        self._create_window()
        self._setup_styles()
        self._create_widgets() # Garante que todos os widgets são criados e populados em self.widgets

        # MUDANÇA AQUI:
        # Após a criação de todos os widgets, se um ID inicial foi fornecido,
        # agendamos a chamada de uma função que preenche e carrega os dados.
        # Usar .after(100, ...) dá um pequeno delay para garantir que a GUI
        # tenha tempo de desenhar e todos os widgets estejam prontos.
        if self.initial_sample_id:
            self.window.after(100, self._auto_load_initial_sample) # Nova função para carregar

    def _auto_load_initial_sample(self):
        """Função auxiliar para preencher a entrada ID e carregar a amostra."""
        self.id_entry.delete(0, tk.END) # Limpa qualquer texto existente
        self.id_entry.insert(0, self.initial_sample_id)
        self.load_sample() # Agora os widgets estão prontos para receber os dados
        
    def _get_options_dict(self):
        options = {header: [] for header in self.options_headers}
        for row in self.options_ws.iter_rows(min_row=2, values_only=True):
            for i, header in enumerate(self.options_headers):
                if i < len(row) and row[i] and row[i] not in options[header]:
                    options[header].append(row[i])
        return options

    def _create_window(self):
        self.window = tk.Toplevel()
        self.window.title("Sample Editor")
        self.window.geometry("800x800")
        self.window.configure(bg='#f0f0f0')
        self.window.resizable(True, True)

    def _setup_styles(self):
        self.style = ttk.Style()
        self.style.configure('Custom.TFrame', background='#f0f0f0')
        self.style.configure('Custom.TLabel', background='#f0f0f0', font=('Arial', 10))
        self.style.configure('Custom.TButton', font=('Arial', 10), padding=5)
        self.style.configure('Custom.TEntry', padding=5)

    def _create_widgets(self):
        self.main_frame = ttk.Frame(self.window, style='Custom.TFrame')
        self.main_frame.pack(fill=tk.BOTH, expand=1, padx=20, pady=20)

        self.canvas = tk.Canvas(self.main_frame, bg='#f0f0f0', highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self.main_frame, orient=tk.VERTICAL, command=self.canvas.yview)
        
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=1)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.frame = ttk.Frame(self.canvas, style='Custom.TFrame')
        self.canvas_frame_id = self.canvas.create_window((0, 0), window=self.frame, anchor="nw")
        
        self.canvas.bind('<Configure>', self._on_canvas_configure)
        self.frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        self._create_header_section()
        self._create_id_section()
        self._create_date_section()
        self._create_form_section()
        self._create_buttons_section()

        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self.window.protocol("WM_DELETE_WINDOW", self._on_closing)

    def _on_canvas_configure(self, event):
        self.canvas.itemconfig(self.canvas_frame_id, width=event.width)
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _create_header_section(self):
        header_frame = ttk.Frame(self.frame, style='Custom.TFrame')
        header_frame.pack(fill=tk.X, pady=(0, 20))

        title_label = ttk.Label(header_frame, text="Sample Editor",
                               font=('Arial', 16, 'bold'), style='Custom.TLabel')
        title_label.pack(pady=(0, 20))

    def _create_id_section(self):
        id_frame = ttk.Frame(self.frame, style='Custom.TFrame')
        id_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(id_frame, text="Load ID (YYYY-XXXXX)",
                 font=('Arial', 10, 'bold'), style='Custom.TLabel').pack()
        
        self.id_entry = ttk.Entry(id_frame, width=30)
        self.id_entry.pack(pady=5)

        load_button = ttk.Button(id_frame, text="Load Sample",
                               command=self.load_sample, style='Custom.TButton')
        load_button.pack(pady=5)

    def _create_date_section(self):
        date_frame = ttk.Frame(self.frame, style='Custom.TFrame')
        date_frame.pack(fill=tk.X, pady=10)

        ttk.Label(date_frame, text="Date",
                 font=('Arial', 10, 'bold'), style='Custom.TLabel').pack()
        
        self.date_entry = DateEntry(date_frame, width=30,
                                  date_pattern="dd/mm/yyyy",
                                  locale="pt_PT",
                                  background='darkblue',
                                  foreground='white')
        self.date_entry.pack(pady=5)

    def _create_form_section(self):
        form_frame = ttk.Frame(self.frame, style='Custom.TFrame')
        form_frame.pack(fill=tk.BOTH, expand=True, pady=10)

        row = 0
        for header in self.data_headers:
            if header in ["ID", "Day", "Month", "Year", "Date", "User"]:
                continue

            ttk.Label(form_frame, text=header,
                     font=('Arial', 10, 'bold'), style='Custom.TLabel').grid(
                row=row, column=0, sticky='w', padx=5, pady=5)

            if header in ["Due Date", "Decision Date"]:
                date_widget = DateEntry(
                    form_frame,
                    width=30,
                    date_pattern="dd/mm/yyyy",
                    locale="pt_PT",
                    selectmode='day',
                    background='darkblue',
                    foreground='white',
                    borderwidth=2,
                    state='normal'
                )
                date_widget.delete(0, 'end')
                date_widget.grid(row=row, column=1, sticky='ew', padx=5, pady=5)
                self.widgets[header] = date_widget

            elif header in self.options_headers:
                cb = ttk.Combobox(form_frame,
                                values=self.options[header],
                                state="readonly", width=30)
                cb.grid(row=row, column=1, sticky='ew', padx=5, pady=5)
                self.widgets[header] = cb

            elif header in ["Description", "Comments", "TTNR"]:
                text_frame = ttk.Frame(form_frame, style='Custom.TFrame')
                text_frame.grid(row=row, column=1, sticky='ew', padx=5, pady=5)

                height = 5 if header == "TTNR" else 5
                text = tk.Text(text_frame, height=height, width=30,
                             font=('Arial', 10), wrap='word')
                text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

                text_scrollbar = ttk.Scrollbar(text_frame, orient=tk.VERTICAL, command=text.yview)
                text_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

                text.config(yscrollcommand=text_scrollbar.set)
                
                self.widgets[header] = text

            else:
                entry = ttk.Entry(form_frame, width=30)
                entry.grid(row=row, column=1, sticky='ew', padx=5, pady=5)
                self.widgets[header] = entry

            row += 1

        form_frame.grid_columnconfigure(1, weight=1)

    def _create_buttons_section(self):
        button_frame = ttk.Frame(self.frame, style='Custom.TFrame')
        button_frame.pack(fill=tk.X, pady=20)

        save_button = ttk.Button(button_frame, text="Save Changes",
                               command=self.save_changes, style='Custom.TButton')
        save_button.pack(side=tk.LEFT, padx=5)

        delete_button = ttk.Button(button_frame, text="Delete Sample",
                                 command=self.delete_sample, style='Custom.TButton')
        delete_button.pack(side=tk.RIGHT, padx=5)

    def _get_ttnr_from_text(self, ttnr_text):
        if not ttnr_text:
            return set()
        
        ttnr_lines = [line.strip() for line in ttnr_text.split('\n') if line.strip()]
        valid_ttnrs_for_folders = set()
        
        for line in ttnr_lines:
            # SANITIZAÇÃO (IMPORTANTE AGORA QUE A RESTRIÇÃO FOI REMOVIDA)
            # Remove caracteres que não são válidos em nomes de arquivos/pastas
            # Mantém letras, números, hífens, underscores e espaços.
            sanitized_line = re.sub(r'[\\/:*?"<>|]', '', line) 
            sanitized_line = sanitized_line.strip() # Remove espaços em branco extras

            if sanitized_line: # Adiciona apenas se não estiver vazio após a sanitização
                valid_ttnrs_for_folders.add(sanitized_line)
            else:
                print(f"Warning: TTNR line '{line}' resulted in an empty string after sanitization and was skipped for folder creation.")
        
        return valid_ttnrs_for_folders


    def load_sample(self):
        try:
            sample_id = self.id_entry.get().strip()
            if not sample_id:
                messagebox.showerror("Error", "Please enter an ID to load.")
                return

            self.original_ttnrs_set.clear() 
            self.current_sample_id = None
            self.row_to_edit_data = None
            self.row_index_in_excel = None

            found = False
            for idx, row in enumerate(self.data_ws.iter_rows(min_row=2)):
                current_row_id = str(row[0].value)
                if current_row_id == sample_id:
                    found = True
                    self.row_index_in_excel = idx + 2
                    self.current_sample_id = sample_id
                    self.row_to_edit_data = {self.data_headers[i]: (c.value if i < len(row) else None) for i, c in enumerate(row)}

                    # Populate widgets
                    # Date Entry
                    try:
                        date_str = self.row_to_edit_data.get("Date")
                        if date_str:
                            date_obj = datetime.strptime(date_str, "%d/%m/%Y").date()
                            self.date_entry.set_date(date_obj)
                        else:
                            self.date_entry.set_date(datetime.now().date())
                    except (ValueError, TypeError):
                        self.date_entry.set_date(datetime.now().date())
                        messagebox.showwarning("Date Error", f"Could not parse 'Date' for ID {sample_id}. Defaulted to today's date.")
                        
                    for header in self.data_headers:
                        if header in ["ID", "Day", "Month", "Year", "Date", "User"]:
                            continue
                        
                        widget = self.widgets.get(header)
                        # Verifica se o widget foi encontrado. Se não, salta este cabeçalho.
                        if widget is None:
                            print(f"Warning: Widget for header '{header}' not found during load_sample for ID {sample_id}.")
                            continue

                        val = self.row_to_edit_data.get(header, "")
                        
                        if header == "TTNR":
                            ttnr_text = str(val) if val is not None else ""
                            # _get_ttnr_from_text agora retorna o set de TTNRs sanitizados para criação de pastas
                            # Mas aqui, queremos exibir o texto bruto no widget, então não usamos o set sanitizado para display
                            self.original_ttnrs_set = self._get_ttnr_from_text(ttnr_text) # Isso é usado para sincronização de pastas
                            widget.delete("1.0", tk.END)
                            widget.insert("1.0", ttnr_text)
                        elif header in ["Due Date", "Decision Date"]:
                            widget.delete(0, 'end')
                            if val:
                                try:
                                    if isinstance(val, str):
                                        widget.set_date(datetime.strptime(val, "%d/%m/%Y").date())
                                    elif isinstance(val, datetime):
                                        widget.set_date(val.date())
                                    else:
                                        widget.set_date(val)
                                except Exception as date_e:
                                    messagebox.showwarning("Date Error", f"Error setting date for '{header}' (ID: {sample_id}): {val} - {date_e}")
                        elif isinstance(widget, tk.Text):
                            widget.delete("1.0", tk.END)
                            widget.insert("1.0", str(val) if val is not None else "")
                        elif isinstance(widget, ttk.Combobox):
                            widget.set(val if val is not None else "")
                        else: # ttk.Entry
                            widget.delete(0, tk.END)
                            widget.insert(0, str(val) if val is not None else "")
                    
                    break
            
            if not found:
                messagebox.showerror("Error", f"ID {sample_id} not found.")
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while loading: {str(e)}")
            print(f"Error details in load_sample: {e}")

    def save_changes(self):
        try:
            if not self.row_to_edit_data or self.row_index_in_excel is None:
                messagebox.showerror("Error", "No sample loaded to save changes.")
                return

            date_obj = self.date_entry.get_date()
            new_values_for_excel = {
                "ID": self.current_sample_id,
                "Date": date_obj.strftime("%d/%m/%Y"),
                "Day": date_obj.day,
                "Month": date_obj.month,
                "Year": date_obj.year,
                "User": self.current_user
            }

            if not new_values_for_excel["ID"]:
                messagebox.showerror("Error", "Sample ID is missing, cannot save.")
                return

            current_ttnr_text = ""
            
            for header in self.data_headers:
                if header in ["ID", "Day", "Month", "Year", "Date", "User"]:
                    continue

                widget = self.widgets.get(header)
                if widget is None:
                    new_values_for_excel[header] = self.row_to_edit_data.get(header, "")
                    continue

                if header in ["Due Date", "Decision Date"]:
                    date_val = widget.get() 
                    new_values_for_excel[header] = date_val if date_val else ""
                elif isinstance(widget, tk.Text):
                    content = widget.get("1.0", "end-1c").strip()
                    new_values_for_excel[header] = content
                    if header == "TTNR":
                        current_ttnr_text = content
                else:
                    new_values_for_excel[header] = widget.get()

            # _get_ttnr_from_text agora retorna o set de TTNRs sanitizados para criação de pastas
            new_ttnrs_set = self._get_ttnr_from_text(current_ttnr_text)
            
            # O Excel deve salvar o texto como digitado, não o set sanitizado.
            # Se você deseja salvar APENAS os TTNRs que foram considerados válidos para pastas no Excel,
            # então você usaria "\n".join(sorted(list(new_ttnrs_set))).
            # Para manter o texto exatamente como o usuário digitou (sem a validação), use current_ttnr_text.
            new_values_for_excel["TTNR"] = current_ttnr_text 

            id_folder_path = os.path.join(self.BASE_FOLDER_PATH, self.current_sample_id)
            
            if not os.path.exists(id_folder_path):
                try:
                    os.makedirs(id_folder_path, exist_ok=True)
                    print(f"Created missing main ID folder: {id_folder_path}")
                except OSError as e:
                    messagebox.showerror("Folder Error", f"Failed to create main ID folder '{id_folder_path}': {e}")
                    return

            ttnrs_to_remove = self.original_ttnrs_set - new_ttnrs_set
            for ttnr in ttnrs_to_remove:
                # Use o TTNR sanitizado para construir o caminho da pasta
                folder_path = os.path.join(id_folder_path, ttnr) 
                if os.path.exists(folder_path):
                    try:
                        os.rmdir(folder_path)
                        print(f"Removed TTNR folder: {folder_path}")
                    except OSError as e:
                        messagebox.showwarning("Folder Warning", f"Could not remove TTNR folder '{folder_path}'. It might not be empty or permissions are denied: {e}")
                else:
                    print(f"Warning: TTNR folder '{folder_path}' not found for removal.")

            ttnrs_to_add = new_ttnrs_set - self.original_ttnrs_set
            for ttnr in ttnrs_to_add:
                # Use o TTNR sanitizado para construir o caminho da pasta
                folder_path = os.path.join(id_folder_path, ttnr)
                try:
                    os.makedirs(folder_path, exist_ok=True)
                    print(f"Created new TTNR folder: {folder_path}")
                except OSError as e:
                    messagebox.showerror("Folder Error", f"Failed to create TTNR folder '{folder_path}': {e}")
            
            self.original_ttnrs_set = new_ttnrs_set 

            for col_idx, header in enumerate(self.data_headers):
                cell_value = new_values_for_excel.get(header, "")
                self.data_ws.cell(row=self.row_index_in_excel, column=col_idx + 1, value=cell_value)

            self.wb.save(self.db_path)
            messagebox.showinfo("Success", "Sample updated successfully. TTNR folders synchronized.")
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while saving: {str(e)}")
            print(f"Error details in save_changes: {e}")

    def delete_sample(self):
        if not self.row_to_edit_data or self.row_index_in_excel is None:
            messagebox.showerror("Error", "No sample loaded to delete.")
            return

        confirm_msg = "Are you sure you want to delete this sample permanently?\n" \
                      "This will also attempt to delete its corresponding folder and all its contents.\n" \
                      "THIS ACTION IS IRREVERSIBLE!"
        if not messagebox.askyesno("Confirm Deletion", confirm_msg):
            return

        try:
            id_to_delete = self.current_sample_id
            if id_to_delete:
                folder_path_to_delete = os.path.join(self.BASE_FOLDER_PATH, id_to_delete)
                if os.path.exists(folder_path_to_delete):
                    try:
                        shutil.rmtree(folder_path_to_delete)
                        messagebox.showinfo("Folder Deletion", f"Successfully deleted folder: {id_to_delete}")
                    except OSError as e:
                        messagebox.showerror("Folder Deletion Error", f"Failed to delete folder '{id_to_delete}': {e}\n"
                                                                      "Please ensure the folder is not open or in use by other applications. Aborting sample deletion from Excel.")
                        return
                else:
                    messagebox.showwarning("Folder Deletion Warning", f"Folder for ID '{id_to_delete}' not found. Skipping folder deletion.")

            self.data_ws.delete_rows(self.row_index_in_excel, 1)
            self.wb.save(self.db_path)
            messagebox.showinfo("Success", "Sample deleted successfully from Excel.")
            self.window.destroy()
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred during deletion: {str(e)}")
            print(f"Error details in delete_sample: {e}")

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    def _on_closing(self):
        self.window.destroy()
