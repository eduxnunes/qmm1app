import tkinter as tk
from tkinter import filedialog, messagebox
import os
import login
import user_management
from permissions import get_allowed_actions
import permission_editor
import new_sample # Importa o módulo new_sample
import graphics   # Importa o módulo graphics (corrigido para o nome do arquivo)
import settings   # Importa o módulo settings
import edit_sample # Importa o módulo edit_sample

class AuditDatabaseApp:
    # Button style configuration
    BUTTON_STYLE = {
        'height': 2,
        'font': ('Arial', 10, 'bold'),
        'bg': '#2196F3',  # Default blue
        'fg': 'white',
        'relief': 'raised'
    }

    # Specific button configurations
    BUTTON_CONFIGS = {
        'select_db': {'text': "Select Database", 'width': 20, 'bg': '#2196F3'},  # Blue
        'login': {'text': "Login", 'width': 20, 'height': 5, 'bg': '#4CAF50'},  # Green
        'new_sample': {'text': "New Sample", 'width': 40, 'height': 5, 'bg': '#2196F3'},  # Blue
        'edit_sample': {'text': "Edit Sample", 'width': 40, 'height': 5, 'bg': '#FF9800'},  # Orange
        'database_info': {'text': "Database Info", 'width': 40, 'height': 5, 'bg': '#9C27B0'},  # Purple
        'settings': {'text': "Settings", 'width': 20, 'height': 5, 'bg': '#607D8B'},  # Gray
        'user_mgmt': {'text': "User Management", 'width': 20, 'height': 5, 'bg': '#795548'},  # Brown
        'access_edit': {'text': "Access Edit", 'width': 20, 'height': 5, 'bg': '#009688'},  # Teal
        'logout': {'text': "Logout", 'width': 20, 'height': 2, 'bg': '#f44336'}  # Red
    }

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Audit Database App")
        self.root.geometry("1920x1080")
        self.root.configure(bg='#f0f0f0')  # Light gray background

        # Initialize variables
        self.db_path = None
        self.current_user = None
        self.current_role = None

        # Create initial UI
        self.create_initial_ui()

    def create_styled_button(self, button_type, command=None, state='normal'):
        # Combine default style with specific button configuration
        button_config = self.BUTTON_STYLE.copy()
        button_config.update(self.BUTTON_CONFIGS.get(button_type, {}))
        if command:
            button_config['command'] = command
        # O argumento 'state' em create_styled_button pode ser uma string (e.g., 'disabled')
        # ou True/False (para habilitado/desabilitado). Ajustei para ser uma string.
        if isinstance(state, str) and state != 'normal':
            button_config['state'] = state
        
        return tk.Button(self.root, **button_config)

    def select_file(self):
        # For development, using a fixed path
        # In production, uncomment the filedialog code
        '''
        file_path = filedialog.askopenfilename(
            title="Select Excel file",
            filetypes=[("Excel Files", "*.xlsx")]
        )
        '''
        # EXERCÍCIO: Substitua pelo seu caminho real do arquivo Excel do banco de dados
        file_path = "H:/QMM/QMM1/02_ISIR/1. ISIR_A-TEST_Tracker/ISIR_A-Test_Database.xlsx" 
        
        if file_path:
            self.db_path = file_path
            self.login_btn.config(state="normal")
            self.status_label.config(text="Database loaded. Login to continue.")

    def do_login(self):
        if not self.db_path:
            messagebox.showwarning("Warning", "Please select a database first.")
            return
        login.run_login(self.launch_main_interface, self.db_path)

    def launch_main_interface(self, path, username, role):
        self.db_path = path
        self.current_user = username
        self.current_role = role
        allowed = get_allowed_actions(role, username, self.db_path)

        # Clear current window
        for widget in self.root.winfo_children():
            widget.destroy()

        # Create welcome label
        tk.Label(self.root, 
                text=f"Welcome, {username} ({role})", 
                font=('Arial', 12, 'bold'),
                bg='#f0f0f0').pack(pady=20)

        # Create main buttons frame
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(expand=True)

        # New Sample Button
        if "new_sample" in allowed:
            # Assume que new_sample.py ainda tem uma função global 'run'
            self.create_styled_button('new_sample', 
                lambda: new_sample.run(self.db_path, self.current_user)).pack(in_=main_frame, pady=10)

        # Edit Sample Button
        if "edit_sample" in allowed:
            # Abre a janela de edição 'vazia' esperando que o usuário digite um ID
            self.create_styled_button('edit_sample', 
                lambda: edit_sample.SampleEditor(self.db_path, self.current_user)).pack(in_=main_frame, pady=10)

        # Database Info Button (MODIFICADO: AGORA CHAMA graphics.run e passa current_user)
        if "graphics" in allowed:
            self.create_styled_button('database_info', 
                lambda: graphics.run(self.db_path, allowed, self.current_user)).pack(in_=main_frame, pady=10)


        # Create admin buttons frame
        admin_frame = tk.Frame(self.root, bg='#f0f0f0')
        admin_frame.pack(pady=20)

        # Settings Button
        if "settings" in allowed:
            self.create_styled_button('settings', 
                lambda: settings.run(self.db_path)).pack(in_=admin_frame, side=tk.LEFT, padx=5)

        # User Management & Access Edit Buttons
        if "user_mgmt" in allowed:
            self.create_styled_button('user_mgmt', 
                lambda: user_management.manage_users(self.db_path)).pack(in_=admin_frame, side=tk.LEFT, padx=5)
            self.create_styled_button('access_edit', 
                lambda: permission_editor.edit_permissions(self.db_path)).pack(in_=admin_frame, side=tk.LEFT, padx=5)

        # Create logout button
        self.create_styled_button('logout', self.reset_app).pack(pady=20)

    def reset_app(self):
        self.current_user = None
        self.current_role = None
        for widget in self.root.winfo_children():
            widget.destroy()
        self.create_initial_ui()

    def create_initial_ui(self):
        # Create title
        tk.Label(self.root, 
                text="QMM1 Database App",
                font=('Arial', 24, 'bold'),
                bg='#f0f0f0',
                pady=30).pack()

        # Create main frame
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(expand=True)

        # Create select database button
        self.create_styled_button('select_db', self.select_file).pack(in_=main_frame, pady=10)
        
        # Create login button (disabled initially)
        self.login_btn = self.create_styled_button('login', self.do_login, state='disabled')
        self.login_btn.pack(in_=main_frame, pady=10)
        
        # Create status label
        self.status_label = tk.Label(self.root, 
                                   text="No database selected",
                                   font=('Arial', 10),
                                   bg='#f0f0f0')
        self.status_label.pack(pady=10)

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = AuditDatabaseApp()
    app.run()