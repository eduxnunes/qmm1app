
import tkinter as tk
from tkinter import messagebox
from openpyxl import load_workbook
import bcrypt

def run_login(callback_after_login, db_path):
    wb = load_workbook(db_path)
    if "Users" not in wb.sheetnames:
        messagebox.showerror("Erro", "A folha 'Users' não existe.")
        return
    ws = wb["Users"]

    users = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row and len(row) >= 3 and row[0] and row[1] and row[2]:
            users[row[0]] = {"hash": row[1], "role": row[2]}

    login_win = tk.Toplevel()
    login_win.title("Login")
    login_win.geometry("300x160")

    tk.Label(login_win, text="Username | viewer").pack(pady=5)
    username_entry = tk.Entry(login_win)
    username_entry.pack()

    tk.Label(login_win, text="Password | viewer123").pack(pady=5)
    password_entry = tk.Entry(login_win, show="*")
    password_entry.pack()

    def authenticate():
        user = username_entry.get().strip()
        pw = password_entry.get().strip()
        if user in users:
            stored_hash = users[user]["hash"]
            if bcrypt.checkpw(pw.encode(), stored_hash.encode()):
                login_win.destroy()
                callback_after_login(db_path, user, users[user]["role"])
                return
        messagebox.showerror("Erro", "Credenciais inválidas.")

    tk.Button(login_win, text="Entrar", command=authenticate).pack(pady=10)
