import tkinter as tk
from tkinter import ttk, messagebox
from openpyxl import load_workbook
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from collections import defaultdict
from datetime import datetime
import numpy as np
import pyperclip
import os
import subprocess
import edit_sample
import webbrowser # Import the webbrowser module

class DataVisualization:
    BASE_FOLDER_PATH = "H:/QMM/QMM1/02_ISIR/1. ISIR_A-TEST_Tracker/Test_Data"

    def __init__(self, db_path, allowed_actions=None, current_user=None):
        self.db_path = db_path
        self.allowed_actions = allowed_actions
        self.current_user = current_user
        self.load_data()
        self.setup_main_window()
        
        self.treeview_data_map = {} 
        
        self.create_widgets()
        self.apply_filters()

    def load_data(self):
        try:
            wb = load_workbook(self.db_path, data_only=True)
            ws = wb["Data"]
            self.headers = [cell.value for cell in ws[1]]
            self.data = [[cell.value for cell in row] for row in ws.iter_rows(min_row=2)]
        except FileNotFoundError:
            messagebox.showerror("Error", f"Database file not found at: {self.db_path}")
            if hasattr(self, 'window') and self.window.winfo_exists():
                self.window.destroy()
            raise
        except KeyError:
            messagebox.showerror("Error", "Sheet 'Data' not found in the database file.")
            if hasattr(self, 'window') and self.window.winfo_exists():
                self.window.destroy()
            raise
        except Exception as e:
            messagebox.showerror("Error", f"Error loading data from Excel: {e}")
            if hasattr(self, 'window') and self.window.winfo_exists():
                self.window.destroy()
            raise

    def setup_main_window(self):
        self.window = tk.Toplevel()
        self.window.title("Data Visualization")
        self.window.geometry("1920x1080")
        self.style = ttk.Style()
        self.configure_styles()

    def configure_styles(self):
        self.style.configure("Custom.TButton",
                           padding=5,
                           font=('Arial', 10))
        self.style.configure("Custom.TLabel",
                           font=('Arial', 10))
        self.style.configure("Custom.TFrame",
                           background='#f0f0f0')
        self.style.configure("Treeview", 
                             rowheight=25,
                             font=('Arial', 9))
        self.style.configure("Treeview.Heading", 
                             font=('Arial', 10, 'bold'))
        self.style.map('Treeview', 
                       background=[('selected', '#347083')],
                       foreground=[('selected', 'white')])

    def create_widgets(self):
        self.create_filter_section()
        self.create_treeview()
        self.create_button_section()

    def create_filter_section(self):
        outer_frame = ttk.Frame(self.window)
        outer_frame.pack(fill="x", padx=10, pady=5)

        canvas = tk.Canvas(outer_frame, height=80)
        scrollbar = ttk.Scrollbar(outer_frame, orient="horizontal", command=canvas.xview)
        
        filter_frame = ttk.Frame(canvas, style="Custom.TFrame")
        
        canvas.configure(xscrollcommand=scrollbar.set)

        scrollbar.pack(side="bottom", fill="x")
        canvas.pack(side="top", fill="x")

        canvas_window = canvas.create_window((0, 0), window=filter_frame, anchor="nw")

        self.filters = {}
        for i, header in enumerate(self.headers):
            ttk.Label(filter_frame, text=header, style="Custom.TLabel").grid(row=0, column=i, sticky="w")
            
            cb = ttk.Combobox(filter_frame, width=15, state="normal") 
            cb.grid(row=1, column=i, padx=2, pady=2, sticky="ew")
            
            unique_values = sorted(set(str(row[i]) for row in self.data if row[i] is not None))
            cb['values'] = [""] + unique_values
            
            cb.bind("<KeyRelease>", lambda e, cb=cb: self.apply_filters_with_typing(cb)) 
            cb.bind("<<ComboboxSelected>>", lambda e: self.apply_filters())
            self.filters[header] = cb

        def update_scroll_region(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
            if filter_frame.winfo_reqwidth() > self.window.winfo_width():
                canvas.configure(width=self.window.winfo_width() - 20)
            else:
                canvas.configure(width=filter_frame.winfo_reqwidth())

        def on_mousewheel(event):
            canvas.xview_scroll(int(-1*(event.delta/120)), "units")

        def on_window_resize(event):
            if filter_frame.winfo_reqwidth() > event.width:
                canvas.configure(width=event.width - 20)
            else:
                canvas.configure(width=filter_frame.winfo_reqwidth())

        filter_frame.bind("<Configure>", update_scroll_region)
        canvas.bind_all("<Shift-MouseWheel>", on_mousewheel) 
        self.window.bind("<Configure>", on_window_resize)

    def create_treeview(self):
        """Cria a tabela Treeview para exibir os dados."""
        tree_frame = ttk.Frame(self.window)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=5)

        y_scrollbar = ttk.Scrollbar(tree_frame)
        x_scrollbar = ttk.Scrollbar(tree_frame, orient="horizontal")
        
        self.tree = ttk.Treeview(tree_frame,
                                columns=self.headers,
                                show="headings",
                                yscrollcommand=y_scrollbar.set,
                                xscrollcommand=x_scrollbar.set)

        y_scrollbar.config(command=self.tree.yview)
        x_scrollbar.config(command=self.tree.xview)

        for h in self.headers:
            self.tree.heading(h, text=h, anchor="w", 
                              command=lambda _h=h: self.sort_treeview(_h))
            self.tree.column(h, width=150, minwidth=50, stretch=False, anchor="w")

        y_scrollbar.pack(side="right", fill="y")
        x_scrollbar.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

        self.tree.bind("<Button-1>", self.on_treeview_click)
        self.tree.bind("<Double-1>", self.on_treeview_double_click)
    
    def sort_treeview(self, col):
        """Ordena a Treeview por coluna."""
        col_index = self.headers.index(col)
        
        data_to_sort = []
        for child_iid in self.tree.get_children(''):
            original_row_index = self.treeview_data_map.get(child_iid)
            if original_row_index is not None:
                value = self.data[original_row_index][col_index]
                data_to_sort.append((value, child_iid))
            else:
                data_to_sort.append(('', child_iid))

        try:
            data_to_sort.sort(key=lambda x: float(x[0]) if str(x[0]) not in ('None', '') else -float('inf'))
        except (ValueError, TypeError):
            data_to_sort.sort(key=lambda x: str(x[0]).lower() if x[0] is not None else '')

        current_heading_text = self.tree.heading(col, "text")
        if current_heading_text.startswith("▼ "):
            data_to_sort.reverse()
            self.tree.heading(col, text="▲ " + col) 
        else:
            self.tree.heading(col, text="▼ " + col) 

        for index, item in enumerate(data_to_sort):
            self.tree.move(item[1], '', index)


    def on_treeview_click(self, event):
        """
        Manipula o evento de clique simples em uma célula da Treeview.
        Se for a coluna 'ID', abre o File Explorer.
        Se for a coluna 'SoftExpert', abre a URL no Mozilla Firefox.
        Caso contrário, abre um pop-up com o texto.
        """
        item_iid = self.tree.identify_row(event.y)
        column_id = self.tree.identify_column(event.x)
        
        if item_iid and column_id:
            col_index = int(column_id.replace("#", "")) - 1
            original_row_index = self.treeview_data_map.get(item_iid)
            
            if original_row_index is not None and 0 <= col_index < len(self.headers):
                column_name = self.headers[col_index]
                cell_value = self.data[original_row_index][col_index]
                full_cell_content = str(cell_value) if cell_value is not None else ""

                if column_name == "ID":
                    self.open_folder_for_id(full_cell_content)
                elif column_name == "SoftExpert":
                    if full_cell_content and full_cell_content != "None": # Ensure there's a valid ID
                        try:
                            # Construct the URL
                            url = f"https://av-seprod/se/v18464/incident/api/view_incident.php?incidentid={full_cell_content}&hideworkspace=true"
                            # Attempt to open in Mozilla Firefox
                            # First, try to get a specific browser instance
                            try:
                                firefox_path = 'C:/Program Files/Mozilla Firefox/firefox.exe' # Common path for Firefox
                                if os.path.exists(firefox_path):
                                    webbrowser.register('firefox', None, webbrowser.BackgroundBrowser(firefox_path))
                                    webbrowser.get('firefox').open_new_tab(url)
                                else:
                                    # Fallback to default if specific path not found
                                    messagebox.showwarning("Firefox Not Found", f"Firefox executable not found at '{firefox_path}'. Opening in default browser.")
                                    webbrowser.open_new_tab(url)
                            except webbrowser.Error:
                                # If firefox isn't registered or a specific executable isn't found/configured, use default
                                messagebox.showwarning("Browser Error", "Could not open Firefox directly. Opening in default web browser.")
                                webbrowser.open_new_tab(url)
                            
                        except Exception as e:
                            messagebox.showerror("Error", f"Failed to open SoftExpert link: {e}")
                    else:
                        messagebox.showinfo("No Link", "No SoftExpert ID found in this cell.")
                else:
                    self.show_popup_for_cell(column_name, full_cell_content)

    def on_treeview_double_click(self, event):
        """
        Manipula o evento de duplo clique em uma célula da Treeview.
        Se for a coluna 'ID' e o usuário tiver permissão, abre a janela de edição.
        """
        item_iid = self.tree.identify_row(event.y)
        column_id = self.tree.identify_column(event.x)
        
        if item_iid and column_id:
            col_index = int(column_id.replace("#", "")) - 1
            original_row_index = self.treeview_data_map.get(item_iid)
            
            if original_row_index is not None and 0 <= col_index < len(self.headers):
                column_name = self.headers[col_index]
                if column_name == "ID":
                    sample_id = str(self.data[original_row_index][col_index])
                    if self.allowed_actions and "edit_sample" in self.allowed_actions:
                        self.open_edit_sample_window(sample_id)
                    else:
                        messagebox.showwarning("Permission Denied", "You do not have permission to edit samples.")
                else:
                    full_cell_content = str(self.data[original_row_index][col_index])
                    self.show_popup_for_cell(column_name, full_cell_content)

    def open_edit_sample_window(self, sample_id):
        """
        Abre a janela SampleEditor com o ID pré-carregado.
        """
        if not self.current_user:
            messagebox.showerror("Error", "Current user not set. Cannot open editor.")
            return

        edit_window = edit_sample.SampleEditor(self.db_path, self.current_user, initial_sample_id=sample_id)
        
        edit_window.window.wait_window()
        self.load_data()
        self.apply_filters()

    def open_folder_for_id(self, sample_id):
        """
        Abre o File Explorer na localização da pasta correspondente ao ID.
        """
        folder_path = os.path.join(self.BASE_FOLDER_PATH, sample_id)
        
        if not os.path.exists(folder_path):
            messagebox.showwarning("Folder Not Found", f"Folder for ID '{sample_id}' not found at:\n{folder_path}")
            return

        try:
            if os.name == 'nt': # Windows
                os.startfile(folder_path)
            elif os.uname().sysname == 'Darwin': # macOS
                subprocess.Popen(['open', folder_path])
            else: # Linux
                subprocess.Popen(['xdg-open', folder_path])
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open folder for ID '{sample_id}': {e}\n"
                                          f"Path: {folder_path}")


    def show_popup_for_cell(self, column_name, content):
        """
        Cria e exibe um pop-up com o texto completo da célula e um botão para copiar.
        """
        popup = tk.Toplevel(self.window)
        popup.title(f"Cell Content: {column_name}")
        popup.geometry("600x400")
        popup.transient(self.window)
        popup.grab_set()

        text_frame = ttk.Frame(popup)
        text_frame.pack(padx=10, pady=10, fill="both", expand=True)

        text_scrollbar_y = ttk.Scrollbar(text_frame)
        text_scrollbar_y.pack(side="right", fill="y")
        text_scrollbar_x = ttk.Scrollbar(text_frame, orient="horizontal")
        text_scrollbar_x.pack(side="bottom", fill="x")

        text_widget = tk.Text(text_frame, wrap="none",
                              yscrollcommand=text_scrollbar_y.set,
                              xscrollcommand=text_scrollbar_x.set,
                              font=('Arial', 10))
        text_widget.insert("1.0", content)
        text_widget.config(state="disabled")
        text_widget.pack(fill="both", expand=True)

        text_scrollbar_y.config(command=text_widget.yview)
        text_scrollbar_x.config(command=text_widget.xview)

        copy_button = ttk.Button(popup, text="Copy to Clipboard", command=lambda: self.copy_to_clipboard(content, popup))
        copy_button.pack(pady=5)

        close_button = ttk.Button(popup, text="Close", command=popup.destroy)
        close_button.pack(pady=5)

        popup.wait_window()

    def copy_to_clipboard(self, text, popup_window):
        """Copia o texto fornecido para a área de transferência."""
        try:
            pyperclip.copy(text)
            messagebox.showinfo("Copy Success", "Text copied to clipboard!", parent=popup_window)
        except Exception as e:
            messagebox.showerror("Copy Error", f"Failed to copy text: {e}", parent=popup_window)

    def create_button_section(self):
        """Cria a seção de botões."""
        button_frame = ttk.Frame(self.window)
        button_frame.pack(pady=10)

        ttk.Button(button_frame,
                  text="Apply Filters",
                  command=self.apply_filters,
                  style="Custom.TButton").pack(side="left", padx=5)
        
        ttk.Button(button_frame,
                  text="Clear Filters",
                  command=self.clear_filters,
                  style="Custom.TButton").pack(side="left", padx=5)
        
        ttk.Button(button_frame,
                  text="KPI's",
                  command=self.show_kpi_graphs,
                  style="Custom.TButton").pack(side="left", padx=5)

    def calculate_response_time(self, date1, date2):
        """
        Calcula a diferença em dias entre duas datas.
        Lida com diferentes formatos de entrada e tipos de dados.
        """
        try:
            if isinstance(date1, str):
                date1 = datetime.strptime(date1, '%d/%m/%Y')
            elif not isinstance(date1, datetime):
                return None
            
            if isinstance(date2, str):
                date2 = datetime.strptime(date2, '%d/%m/%Y')
            elif not isinstance(date2, datetime):
                return None
                
            if isinstance(date1, datetime) and isinstance(date2, datetime):
                days = (date2 - date1).days
                return days
            return None
        except ValueError:
            return None
        except Exception:
            return None

    def apply_filters(self):
        """Aplica os filtros selecionados e atualiza a Treeview.
           Esta é a função principal de filtro, para ser chamada por botões."""
        self._perform_filtering()

    def apply_filters_with_typing(self, combobox_widget):
        """Aplica os filtros selecionados, incluindo o texto digitado na combobox."""
        self._perform_filtering()

    def _perform_filtering(self):
        """Lógica interna para aplicar os filtros e atualizar a Treeview."""
        for row_iid in self.tree.get_children():
            self.tree.delete(row_iid)
        
        self.treeview_data_map.clear()

        iid_counter = 0

        for original_row_index, row_data in enumerate(self.data):
            if self.matches_filters(row_data):
                display_values = []
                for i, value in enumerate(row_data):
                    str_value = str(value) if value is not None else ""
                    if len(str_value) > 50 and self.headers[i] != "ID":
                        display_values.append(str_value[:47] + "...")
                    else:
                        display_values.append(str_value)
                
                current_iid = f"item_{iid_counter}"
                self.tree.insert("", "end", values=display_values, iid=current_iid)
                
                self.treeview_data_map[current_iid] = original_row_index
                iid_counter += 1


    def matches_filters(self, row_data):
        """Verifica se uma linha de dados corresponde aos filtros selecionados.
           Agora permite correspondência parcial (substring) para texto digitado."""
        for i, header in enumerate(self.headers):
            filter_text = self.filters[header].get()
            
            if filter_text:
                cell_value_str = str(row_data[i]) if row_data[i] is not None else ""
                
                if filter_text.lower() not in cell_value_str.lower():
                    return False
        return True

    def clear_filters(self):
        """Limpa todos os filtros e reaplica-os."""
        for cb in self.filters.values():
            cb.set("")
        self.apply_filters()

    def show_kpi_graphs(self):
        """
        Gera e exibe os gráficos de KPIs em uma nova janela Toplevel.
        Esta função foi refatorada para recriar todos os widgets de KPI a cada chamada,
        garantindo que não haja problemas com widgets descartados de chamadas anteriores.
        """
        # Se uma janela de KPI já existe e está ativa, destrua-a para recriar
        if hasattr(self, 'kpi_window') and self.kpi_window.winfo_exists():
            self.kpi_window.destroy()

        self.kpi_window = tk.Toplevel()
        self.kpi_window.title("KPI Graphs by Audit Type")
        self.kpi_window.geometry("1600x800")

        # Container principal dentro da janela de KPI
        kpi_main_container = tk.Frame(self.kpi_window)
        kpi_main_container.pack(fill="both", expand=True)

        # Frame de controle (filtros de ano/tipo de auditoria)
        control_frame = tk.Frame(kpi_main_container)
        control_frame.pack(pady=10)

        tk.Label(control_frame, text="Year:").pack(side="left")
        try:
            idx_year = self.headers.index("Year")
            year_values = sorted({str(row[idx_year]) for row in self.data if row[idx_year] is not None})
            self.year_cb_inner = ttk.Combobox(control_frame, values=[""] + year_values, width=10, state="readonly")
            self.year_cb_inner.pack(side="left", padx=5)
        except ValueError:
            self.year_cb_inner = ttk.Combobox(control_frame, values=[""], width=10, state="readonly")
            self.year_cb_inner.pack(side="left", padx=5)
            messagebox.showwarning("Warning", "Column 'Year' not found. KPI year filtering might be limited.")


        tk.Label(control_frame, text="Audit Type:").pack(side="left")
        try:
            idx_audit_type = self.headers.index("Audit Type")
            audit_types = sorted({str(row[idx_audit_type]) for row in self.data if row[idx_audit_type]})
            self.audit_cb_inner = ttk.Combobox(control_frame, values=[""] + audit_types, width=15, state="readonly")
            self.audit_cb_inner.pack(side="left", padx=5)
        except ValueError:
            messagebox.showwarning("Warning", "Column 'Audit Type' not found. KPI generation might be limited.")
            self.audit_cb_inner = ttk.Combobox(control_frame, values=[""], width=15, state="readonly")
            self.audit_cb_inner.pack(side="left", padx=5)

        tk.Button(control_frame, text="Filter", command=self.generate_kpis_charts).pack(side="left", padx=10)

        if self.allowed_actions and "edit_target" in self.allowed_actions:
            try:
                import edit_target
                tk.Button(control_frame, text="Edit Targets", 
                         command=lambda: edit_target.run(self.db_path)).pack(side="left", padx=10)
            except ImportError:
                messagebox.showwarning("Warning", "The 'edit_target' module was not found. Please ensure 'edit_target.py' is in the same directory.")

        # Canvas para a área de gráficos rolável
        self.kpi_canvas = tk.Canvas(kpi_main_container)
        self.kpi_scrollbar = ttk.Scrollbar(kpi_main_container, orient="vertical", command=self.kpi_canvas.yview)
        self.kpi_scrollable_frame = tk.Frame(self.kpi_canvas)

        self.kpi_canvas.configure(yscrollcommand=self.kpi_scrollbar.set)
        self.kpi_scrollbar.pack(side="right", fill="y")
        self.kpi_canvas.pack(side="left", fill="both", expand=True)

        self.kpi_canvas_window_id = self.kpi_canvas.create_window((0, 0), window=self.kpi_scrollable_frame, anchor="nw")

        # Frames para os gráficos e informações dentro do frame rolável
        self.kpi_chart_frame = tk.Frame(self.kpi_scrollable_frame)
        self.kpi_chart_frame.pack(fill="both", expand=True)

        self.kpi_info_frame = tk.Frame(self.kpi_scrollable_frame)
        self.kpi_info_frame.pack()

        def configure_scroll_region(event):
            self.kpi_canvas.configure(scrollregion=self.kpi_canvas.bbox("all"))

        def configure_canvas_width(event):
            self.kpi_canvas.itemconfig(self.kpi_canvas_window_id, width=event.width)

        self.kpi_scrollable_frame.bind("<Configure>", configure_scroll_region)
        self.kpi_canvas.bind("<Configure>", configure_canvas_width)

        def on_mousewheel_kpi(event): # Nova função de mousewheel para a janela de KPI
            self.kpi_canvas.yview_scroll(int(-1*(event.delta/120)), "units")

        self.kpi_window.bind("<MouseWheel>", on_mousewheel_kpi) # Bind na janela de KPI

        self.generate_kpis_charts() # Gera os KPIs iniciais ao abrir a janela

    def generate_kpis_charts(self):
        """
        Gera e exibe os gráficos de KPIs com base nos dados filtrados.
        Esta é a função chamada pelo botão "Filter" na janela de KPIs.
        """
        # Limpa os gráficos e informações anteriores dos frames de KPI
        for widget in self.kpi_chart_frame.winfo_children():
            widget.destroy()
        for widget in self.kpi_info_frame.winfo_children():
            widget.destroy()
        
        required_cols = ["OK/NOK", "Section", "Audit Type", "Year", "Month", "Date", "Due Date", "Decision Date"]
        col_indices = {}
        try:
            for col_name in required_cols:
                col_indices[col_name] = self.headers.index(col_name)
        except ValueError as e:
            messagebox.showwarning("Warning", f"Missing required column for KPI generation: {e}. Some KPIs might not be generated.")
            tk.Label(self.kpi_chart_frame, text=f"Error: Missing column for KPIs ({e}).", 
                     font=('Arial', 12, 'italic'), fg='red').pack(pady=50)
            return

        idx_oknok = col_indices["OK/NOK"]
        idx_section = col_indices["Section"]
        idx_audit_type = col_indices["Audit Type"]
        idx_year = col_indices["Year"]
        idx_month = col_indices["Month"]
        idx_date = col_indices["Date"]
        idx_due_date = col_indices["Due Date"]
        idx_decision_date = col_indices["Decision Date"]

        # Filtra os dados com base nos ComboBoxes da janela de KPI
        filtered_rows = [
            row for row in self.data
            if (not self.year_cb_inner.get() or (isinstance(row[idx_year], (int, float)) and str(int(row[idx_year])) == self.year_cb_inner.get()))
            and (not self.audit_cb_inner.get() or str(row[idx_audit_type]) == self.audit_cb_inner.get())
        ]
        
        if not filtered_rows:
            tk.Label(self.kpi_chart_frame, text="No data available for the selected filters to generate KPIs.", 
                     font=('Arial', 12, 'italic'), fg='gray').pack(pady=50)
            return

        # ---- Gráfico Radar: Distribuição por Seção ----
        section_counts_total = {}
        section_counts_nok = {}
        for row in filtered_rows:
            section = str(row[idx_section]) if row[idx_section] else "N/A"
            status = str(row[idx_oknok]) if row[idx_oknok] else "UNKNOWN"
            section_counts_total[section] = section_counts_total.get(section, 0) + 1
            if status.upper() == "NOK":
                section_counts_nok[section] = section_counts_nok.get(section, 0) + 1

        plt.style.use('seaborn')
        fig, axes = plt.subplots(1, 4, figsize=(25, 6))
        ax1, ax2, ax3, ax4 = axes

        # Configure ax1 for radar chart
        if section_counts_total:
            labels = sorted(list(set(section_counts_total.keys()) | set(section_counts_nok.keys())))
            if not labels:
                ax1.text(0.5, 0.5, 'No section data', transform=ax1.transAxes, 
                         horizontalalignment='center', verticalalignment='center', fontsize=12, color='gray')
                ax1.axis('off')
            else:
                # Remove ax1 from the subplot grid to convert it to a polar projection
                fig.delaxes(ax1)
                ax1 = fig.add_subplot(141, polar=True)

                values_total = [section_counts_total.get(label, 0) for label in labels]
                values_nok = [section_counts_nok.get(label, 0) for label in labels]
                
                angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
                values_total += values_total[:1] # Complete the loop
                values_nok += values_nok[:1]     # Complete the loop
                angles += angles[:1]             # Complete the loop

                ax1.plot(angles, values_total, color='#2E86C1', linewidth=2, label='Total(Sampling)')
                ax1.plot(angles, values_nok, color='#E74C3C', linewidth=2, label='NOK')
                ax1.fill(angles, values_total, color='#2E86C1', alpha=0.25)
                ax1.fill(angles, values_nok, color='#E74C3C', alpha=0.25)

                for i, angle in enumerate(angles[:-1]):
                    ax1.text(angle, values_total[i], f'{values_total[i]}', 
                            ha='center', va='bottom', fontsize=9)
                    if values_nok[i] > 0:
                        ax1.text(angle, values_nok[i], f'{values_nok[i]}', 
                                ha='center', va='top', fontsize=9, color='#E74C3C')
                
                ax1.set_xticks(angles[:-1])
                ax1.set_xticklabels(labels)
                ax1.set_title("Distribution by Section", pad=20, fontsize=12, fontweight='bold')
                ax1.grid(True, alpha=0.3)
                ax1.legend(loc="upper right", bbox_to_anchor=(1.2, 1.1))
        else:
            # If no data, reuse the original ax1 for text
            ax1.text(0.5, 0.5, 'No section data', transform=ax1.transAxes, 
                     horizontalalignment='center', verticalalignment='center', fontsize=12, color='gray')
            ax1.axis('off')


        # ---- Gráfico de Barras: Distribuição Mensal ----
        months = np.arange(1, 13)
        # CRITICAL FIX: Initialize dictionary with uppercase keys
        results = {m: {"OK": 0, "NOK": 0, "UNDER ANALYSIS": 0} for m in range(1, 13)}

        for row in filtered_rows:
            month = row[idx_month]
            if isinstance(month, int) and 1 <= month <= 12:
                status = str(row[idx_oknok]).strip().upper() if row[idx_oknok] else "UNKNOWN"
                
                # Increment counts for recognized statuses
                if status == "OK":
                    results[month]["OK"] += 1
                elif status == "NOK":
                    results[month]["NOK"] += 1
                elif status == "UNDER ANALYSIS":
                    results[month]["UNDER ANALYSIS"] += 1
                # else: pass (ignore unknown statuses or handle as needed)


        # Calculate counts from the corrected results dictionary
        sampling_counts = [
            results[m]["OK"] + results[m]["NOK"] + results[m]["UNDER ANALYSIS"] 
            for m in range(1, 13)
        ]
        rejection_counts = [results[m].get("NOK", 0) for m in range(1, 13)]
        underanalysis_counts = [results[m].get("UNDER ANALYSIS", 0) for m in range(1, 13)] # Corrected key

        bar_width = 0.25 # Adjusted bar width
        x = np.arange(len(months))

        # Calculate offsets for three bars to prevent overlap
        offset_sampling = -bar_width
        offset_rejection = 0
        offset_under_analysis = bar_width

        bars1 = ax2.bar(x + offset_sampling, sampling_counts, bar_width, 
                      label='Total Samples', color='#2E86C1', alpha=0.8)
        bars2 = ax2.bar(x + offset_rejection, rejection_counts, bar_width, 
                      label='Rejections', color='#E74C3C', alpha=0.8)
        bars3 = ax2.bar(x + offset_under_analysis, underanalysis_counts, bar_width, 
                      label='Under Analysis', color='#27AE60', alpha=0.8)

        # Annotate bars with their values, adjusting x-position
        for i, (total, rej, und) in enumerate(zip(sampling_counts, rejection_counts, underanalysis_counts)):
            if total > 0:
                ax2.text(x[i] + offset_sampling, total, str(total), 
                        ha='center', va='bottom', fontsize=9)
            if rej > 0:
                ax2.text(x[i] + offset_rejection, rej, str(rej), 
                        ha='center', va='bottom', fontsize=9, color='#E74C3C')
            if und > 0:
                ax2.text(x[i] + offset_under_analysis, und, str(und), 
                        ha='center', va='bottom', fontsize=9, color='#27AE60')
                
        target_value = None
        try:
            wb_target = load_workbook(self.db_path, data_only=True)
            ws_target = wb_target["Target"]
            target_map = {
                str(row[0]): row[1]
                for row in ws_target.iter_rows(min_row=2, values_only=True)
                if row[0] and row[1] is not None
            }
            target_value = target_map.get(str(self.audit_cb_inner.get()), None)
            if target_value is not None:
                ax2.axhline(y=target_value, color="#27AE60", linestyle="--", linewidth=2, 
                          label=f"Target: {target_value}")
        except (KeyError, FileNotFoundError):
            pass
        except Exception as e:
            print(f"Error loading target value: {e}")

        ax2.set_title("Monthly Distribution", fontsize=12, fontweight='bold', pad=20)
        ax2.set_xlabel("Month", fontsize=10)
        ax2.set_ylabel("Count", fontsize=10)
        ax2.set_xticks(x)
        ax2.set_xticklabels(months)
        ax2.legend()

        # --- Remaining charts (Response Times) ---
        response_times = defaultdict(list)
        for row in filtered_rows:
            month = row[idx_month]
            if isinstance(month, int) and 1 <= month <= 12 and row[idx_date] and row[idx_decision_date]:
                response_time = self.calculate_response_time(row[idx_date], row[idx_decision_date])
                if response_time is not None:
                    response_times[month].append(response_time)

        avg_response_times = []
        for m in range(1, 13):
            times = response_times.get(m, [])
            avg_response_times.append(sum(times) / len(times) if times else 0)

        ax3.plot(months, avg_response_times, marker='o', color='#8E44AD', linewidth=2)
        ax3.fill_between(months, avg_response_times, 0, alpha=0.2, color='#8E44AD')
        ax3.set_title("Avg. Response Time by Month\n(Decision Date - Date)", 
                     fontsize=12, fontweight='bold', pad=20)
        ax3.set_xlabel("Month", fontsize=10)
        ax3.set_ylabel("Days", fontsize=10)
        ax3.grid(True, alpha=0.3)

        for i, v in enumerate(avg_response_times):
            if v != 0:
                n_samples = len(response_times.get(i + 1, []))
                ax3.text(i + 1, v, f'{v:.1f}\n(n={n_samples})', 
                        ha='center', va='bottom' if v > 0 else 'top', fontsize=9)

        all_values_rt = [v for v in avg_response_times if v != 0]
        if all_values_rt:
            ymin = min(all_values_rt)
            ymax = max(all_values_rt)
            padding = (ymax - ymin) * 0.1 if ymax != ymin else 1
            ax3.set_ylim(bottom=ymin - padding if ymin < 0 else None,
                         top=ymax + padding if ymax > 0 else None)
        ax3.axhline(y=0, color='black', linestyle='-', linewidth=0.5)

        due_date_response_times = defaultdict(list)
        for row in filtered_rows:
            month = row[idx_month]
            if isinstance(month, int) and 1 <= month <= 12 and row[idx_due_date] and row[idx_decision_date]:
                response_time = self.calculate_response_time(row[idx_due_date], row[idx_decision_date])
                if response_time is not None:
                    due_date_response_times[month].append(response_time)

        avg_due_date_response_times = []
        for m in range(1, 13):
            times = due_date_response_times.get(m, [])
            avg_due_date_response_times.append(sum(times) / len(times) if times else 0)

        ax4.plot(months, avg_due_date_response_times, marker='o', color='#27AE60', linewidth=2)
        ax4.fill_between(months, avg_due_date_response_times, 0, alpha=0.2, color='#27AE60')
        ax4.set_title("Avg. Response Time by Month\n(Decision Date - Due Date)", 
                     fontsize=12, fontweight='bold', pad=20)
        ax4.set_xlabel("Month", fontsize=10)
        ax4.set_ylabel("Days", fontsize=10)
        ax4.grid(True, alpha=0.3)

        for i, v in enumerate(avg_due_date_response_times):
            if v != 0:
                n_samples = len(due_date_response_times.get(i + 1, []))
                ax4.text(i + 1, v, f'{v:.1f}\n(n={n_samples})', 
                        ha='center', va='bottom' if v > 0 else 'top', fontsize=9)

        all_values_ddrt = [v for v in avg_due_date_response_times if v != 0]
        if all_values_ddrt:
            ymin = min(all_values_ddrt)
            ymax = max(all_values_ddrt)
            padding = (ymax - ymin) * 0.1 if ymax != ymin else 1
            ax4.set_ylim(bottom=ymin - padding if ymin < 0 else None,
                         top=ymax + padding if ymax > 0 else None)
        ax4.axhline(y=0, color='black', linestyle='-', linewidth=0.5)

        plt.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.kpi_chart_frame) # Usar self.kpi_chart_frame
        canvas.draw()
        canvas.get_tk_widget().pack(padx=10, pady=10, fill="both", expand=True)

        year_filter = self.year_cb_inner.get()
        if year_filter:
            current_year = datetime.now().year
            mes_atual = datetime.now().month if str(current_year) == year_filter else 12
            
            total_amostras = sum(sampling_counts[:mes_atual])
            total_rejeicoes = sum(rejection_counts[:mes_atual])
            
            media_amostras = total_amostras / mes_atual if mes_atual > 0 else 0
            media_rejeicoes = total_rejeicoes / mes_atual if mes_atual > 0 else 0

            stats_frame = ttk.Frame(self.kpi_info_frame) # Usar self.kpi_info_frame
            stats_frame.pack(pady=10)

            stats_style = {"font": ("Arial", 11), "background": "#f0f0f0", "pady": 5, "padx": 10}
            
            tk.Label(stats_frame, 
                    text=f"Monthly average of samples ({year_filter}): {media_amostras:.2f}", 
                    fg="#2E86C1", **stats_style).pack(anchor="w")
            
            tk.Label(stats_frame, 
                    text=f"Monthly average of rejections ({year_filter}): {media_rejeicoes:.2f}", 
                    fg="#E74C3C", **stats_style).pack(anchor="w")
            
            all_response_times_flat = [rt for rts in response_times.values() for rt in rts]
            if all_response_times_flat:
                avg_response = np.mean(all_response_times_flat)
                tk.Label(stats_frame, 
                        text=f"Average response time (Decision Date - Date): {avg_response:.1f} days", 
                        fg="#8E44AD", **stats_style).pack(anchor="w")
            
            all_due_date_response_times_flat = [rt for rts in due_date_response_times.values() for rt in rts]
            if all_due_date_response_times_flat:
                avg_due_date_response = np.mean(all_due_date_response_times_flat)
                tk.Label(stats_frame, 
                        text=f"Average response time (Decision Date - Due Date): {avg_due_date_response:.1f} days", 
                        fg="#27AE60", **stats_style).pack(anchor="w")

# Função para iniciar a aplicação
def run(db_path, allowed_actions=None, current_user=None):
    root = tk.Tk()
    root.withdraw()
    app = DataVisualization(db_path, allowed_actions, current_user)
    return app