
from openpyxl import load_workbook

def get_allowed_actions(role, user=None, db_path=None):
    default_permissions = {
        "admin": ["new_sample", "edit_sample", "settings", "graphics", "user_mgmt"],
        "auditor": ["new_sample", "edit_sample", "graphics"],
        "viewer": ["graphics"]
    }
    if db_path and user:
        try:
            wb = load_workbook(db_path, data_only=True)
            ws = wb["Users"]
            for row in ws.iter_rows(min_row=2, values_only=True):
                if row[0] == user and len(row) >= 4 and row[3]:
                    return row[3].split(",")
        except:
            pass
    return default_permissions.get(role, [])
