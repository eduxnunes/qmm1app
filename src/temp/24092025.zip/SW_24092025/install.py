import subprocess
import sys
import os

def install_libraries():
    """
    Attempts to install a list of specified Python libraries.
    It upgrades pip first, then tries to install each library,
    falling back to a '--user' install if the first attempt fails.
    Provides a summary of successful and failed installations.
    """
    # List of all required libraries
    # Note: 'tkinter' is a built-in Python module and does not need pip installation.
    libraries = [
        'openpyxl',
        'bcrypt',
        'tkcalendar',
        'matplotlib',
        'numpy',
        'pillow',  # PIL/Pillow for image handling, often used with Tkinter
        'pandas',  # Common data manipulation library
        'pyperclip', # For clipboard operations
    ]

    print("="*50)
    print("Starting library installation process...")
    print("="*50)
    
    successful_installs = 0
    failed_installs = []

    # --- Step 1: Upgrade pip itself ---
    try:
        print("\nAttempting to upgrade pip...")
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '--upgrade', 'pip'])
        print("Pip upgraded successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Warning: Failed to upgrade pip. Error: {e}")
        print("Continuing with library installations, but issues might arise.")
    except Exception as e:
        print(f"Warning: An unexpected error occurred during pip upgrade: {e}")
        print("Continuing with library installations.")

    # --- Step 2: Install each library ---
    for lib in libraries:
        print(f"\nAttempting to install {lib}...")
        
        # Tkinter is a special case: it's part of Python's standard library.
        # On some Linux distributions, you might need to install a system package like python3-tk.
        # Pip should *not* be used to install it.
        if lib.lower() == 'tkinter':
            print("  Note: 'tkinter' is part of Python's standard library and doesn't need pip installation.")
            print("  If you are on Linux and encounter issues, try 'sudo apt-get install python3-tk'.")
            continue
            
        try:
            # Try installing normally first
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', lib])
            print(f"  Successfully installed {lib}")
            successful_installs += 1
            
        except subprocess.CalledProcessError:
            # If the normal install fails, try with --user flag
            print(f"  Initial install of {lib} failed. Retrying with '--user' flag...")
            try:
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', '--user', lib])
                print(f"  Successfully installed {lib} with '--user' flag.")
                successful_installs += 1
            except subprocess.CalledProcessError as e:
                failed_installs.append(lib)
                print(f"  Failed to install {lib} even with '--user' flag. Error: {e}")
            except Exception as e:
                failed_installs.append(lib)
                print(f"  An unexpected error occurred while installing {lib} with '--user': {e}")
        except Exception as e:
            failed_installs.append(lib)
            print(f"  An unexpected error occurred while installing {lib}: {e}")

    # --- Step 3: Print installation summary ---
    print("\n" + "="*50)
    print("INSTALLATION SUMMARY:")
    print(f"  Successfully installed: {successful_installs} libraries")
    if failed_installs:
        print(f"  Failed to install: {len(failed_installs)} libraries")
        print("  Failed libraries: " + ", ".join(failed_installs))
    else:
        print("  All specified libraries installed successfully!")
    print("="*50)

    # --- Step 4: Additional Information and Troubleshooting ---
    print("\nAdditional Notes:")
    print("- The following modules are part of Python's standard library and do not need 'pip' installation:")
    print("  - `tkinter` (including `ttk`, `messagebox`, `filedialog`, `simpledialog`)")
    print("  - `re` (regular expressions)")
    print("  - `collections` (e.g., `deque`, `Counter`)")
    print("  - `datetime`")
    print("  - `os`")
    print("  - `sys`")

    if failed_installs:
        print("\nTroubleshooting Tips for Failed Installations:")
        print("1.  **Check your internet connection.**")
        print("2.  **Try installing the failed packages individually** using `pip install <package_name>`.")
        print("3.  **Run the script with administrator/root privileges** (e.g., 'Run as administrator' on Windows, `sudo python3 install_script.py` on Linux/macOS) if global installation is desired and permissions are an issue.")
        print("4.  **For Linux users:** If `tkinter` is not working, try installing `python3-tk` using your system's package manager (e.g., `sudo apt-get install python3-tk` on Debian/Ubuntu).")
        if os.name == 'nt':  # Windows
            print("5.  **For Windows users:** Some packages require compilation. Ensure you have the Microsoft Visual C++ Build Tools installed (available from Microsoft's website).")
        print("6.  **Check Python version compatibility:** Ensure the library supports your Python version.")

def create_requirements_file():
    """
    Creates a 'requirements.txt' file in the current directory,
    listing all necessary Python packages for this project.
    """
    requirements_content = """
openpyxl
bcrypt
tkcalendar
matplotlib
numpy
pillow
pandas
pyperclip
"""
    try:
        with open('requirements.txt', 'w') as f:
            f.write(requirements_content.strip())
        print("\n'requirements.txt' file created successfully in the current directory.")
        print("You can inspect its content or use 'pip install -r requirements.txt'.")
    except Exception as e:
        print(f"Error: Failed to create 'requirements.txt': {e}")

def install_from_requirements():
    """
    Attempts to install libraries listed in 'requirements.txt'.
    """
    if not os.path.exists('requirements.txt'):
        print("\nError: 'requirements.txt' not found. Please create it first (e.g., using option 2) or ensure it's in the current directory.")
        return

    print("\n" + "="*50)
    print("Installing libraries from 'requirements.txt'...")
    print("="*50)
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'])
        print("\nSuccessfully installed all requirements listed in 'requirements.txt'.")
    except subprocess.CalledProcessError as e:
        print(f"\nError: Failed to install some libraries from 'requirements.txt'.")
        print(f"Please check the error messages above. Command failed with: {e}")
    except Exception as e:
        print(f"\nAn unexpected error occurred during installation from 'requirements.txt': {e}")
    print("="*50)


def main():
    """
    Main function to provide a menu-driven interface for library installation.
    """
    while True:
        print("\n" + "="*50)
        print("PYTHON LIBRARY INSTALLATION TOOL")
        print("="*50)
        print("Please choose an option:")
        print("1. Install all libraries directly (uses internal list)")
        print("2. Create 'requirements.txt' file (does NOT install)")
        print("3. Install libraries from an existing 'requirements.txt' file")
        print("4. Exit")
        print("="*50)
        
        choice = input("Enter your choice (1-4): ").strip()
        
        if choice == '1':
            install_libraries()
        elif choice == '2':
            create_requirements_file()
        elif choice == '3':
            install_from_requirements()
        elif choice == '4':
            print("Exiting the installation tool. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a number between 1 and 4.")

if __name__ == "__main__":
    main()