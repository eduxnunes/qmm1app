import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
from openpyxl import load_workbook
import bcrypt
import re
from typing import List, Tuple
from datetime import datetime

class PasswordChangeDialog(tk.Toplevel):
    def __init__(self, parent, username: str):
        super().__init__(parent)
        self.username = username
        self.result = None
        
        self.title(f"Change Password - {username}")
        self.geometry("400x400")  # Increased height for better layout
        self.resizable(False, False)
        
        # Make the dialog modal
        self.transient(parent)
        self.grab_set()
        
        self.create_widgets()
        self.center_window()

    def create_widgets(self):
        # Create main frame with padding
        main_frame = ttk.Frame(self, padding="20")
        main_frame.pack(fill="both", expand=True)

        # Style configuration
        style = ttk.Style()
        style.configure("Save.TButton", background="#4CAF50", padding=10)  # Green
        style.configure("Cancel.TButton", background="#f44336", padding=10)  # Red

        # Title label
        title_label = ttk.Label(main_frame, 
                               text=f"Change Password for {self.username}",
                               font=('Arial', 12, 'bold'))
        title_label.pack(pady=(0, 20))

        # Current password
        ttk.Label(main_frame, text="Current Password:", font=('Arial', 10)).pack(fill="x", pady=(5,2))
        self.current_pw = ttk.Entry(main_frame, show="*")
        self.current_pw.pack(fill="x", pady=(0,10))

        # New password
        ttk.Label(main_frame, text="New Password (min 8 characters):", font=('Arial', 10)).pack(fill="x", pady=(5,2)) # Updated label
        self.new_pw = ttk.Entry(main_frame, show="*")
        self.new_pw.pack(fill="x", pady=(0,10))

        # Confirm new password
        ttk.Label(main_frame, text="Confirm New Password:", font=('Arial', 10)).pack(fill="x", pady=(5,2))
        self.confirm_pw = ttk.Entry(main_frame, show="*")
        self.confirm_pw.pack(fill="x", pady=(0,10))

        # Password strength indicator
        self.strength_var = tk.StringVar(value="Password Strength: ")
        self.strength_label = ttk.Label(main_frame, textvariable=self.strength_var, font=('Arial', 9))
        self.strength_label.pack(fill="x", pady=(5,2))

        # Progress bar for password strength
        self.strength_bar = ttk.Progressbar(main_frame, length=200, mode='determinate')
        self.strength_bar.pack(fill="x", pady=(0,20))

        # Bind password strength checker
        self.new_pw.bind('<KeyRelease>', self.check_password_strength)

        # Buttons frame
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill="x", pady=(20,0))

        # Save button with distinct styling
        save_button = tk.Button(button_frame, 
                              text="Save Changes",
                              command=self.validate_and_save,
                              bg='#4CAF50',  # Green
                              fg='white',
                              font=('Arial', 10, 'bold'),
                              pady=8,
                              width=15)
        save_button.pack(side="left", padx=5)

        # Cancel button with distinct styling
        cancel_button = tk.Button(button_frame, 
                                text="Cancel",
                                command=self.cancel,
                                bg='#f44336',  # Red
                                fg='white',
                                font=('Arial', 10, 'bold'),
                                pady=8,
                                width=15)
        cancel_button.pack(side="right", padx=5)

    def center_window(self):
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f'{width}x{height}+{x}+{y}')

    def check_password_strength(self, event=None):
        password = self.new_pw.get()
        strength = 0
        
        # Only check for length as per the new requirement
        if len(password) >= 8:
            strength = 100 # Max strength if length requirement met
        else:
            strength = (len(password) / 8) * 100 if len(password) > 0 else 0

        # Update strength indicator
        self.strength_bar['value'] = strength
        if strength == 100:
            color = 'green'
            strength_text = 'Meets Requirement'
        else:
            color = 'red'
            strength_text = f'Too Short ({len(password)}/8)'

        self.strength_var.set(f"Password Status: {strength_text}")
        self.strength_label.configure(foreground=color)

    def validate_and_save(self):
        current = self.current_pw.get()
        new = self.new_pw.get()
        confirm = self.confirm_pw.get()

        if not all([current, new, confirm]):
            messagebox.showerror("Error", "All fields are required!")
            return

        if new != confirm:
            messagebox.showerror("Error", "New passwords do not match!")
            return

        # ONLY enforce minimum length of 8 characters
        if len(new) < 8:
            messagebox.showerror("Error", "Password must be at least 8 characters long!")
            return

        # Removed all other password complexity checks (uppercase, lowercase, number, special char)
        # as per the new requirement.

        self.result = (current, new)
        self.destroy()

    def cancel(self):
        self.result = None
        self.destroy()

# The UserManager class remains unchanged as its validate_password already only checks length.
# (I'm including it below for context, but its content is the same as your original script
# except for the comment about its validate_password method)
class UserManager:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.wb = load_workbook(db_path)
        self.setup_worksheet()
        self.create_gui()

    def setup_worksheet(self):
        if "Users" not in self.wb.sheetnames:
            self.ws = self.wb.create_sheet("Users")
            self.ws.append(["Username", "Password_Hash", "Role"])
        else:
            self.ws = self.wb["Users"]

    def create_gui(self):
        self.window = tk.Toplevel()
        self.window.title("User Management System")
        self.window.geometry("400x500")
        self.window.resizable(False, False)
        
        self.create_widgets()
        self.refresh_user_list()

    def create_widgets(self):
        # Create frame for buttons
        button_frame = ttk.Frame(self.window)
        button_frame.pack(fill="x", padx=10, pady=5)

        # Style configuration
        style = ttk.Style()
        style.configure("Action.TButton", padding=5)

        # Buttons
        ttk.Button(button_frame, text="Add/Update User", 
                  command=self.add_user, style="Action.TButton").pack(fill="x", pady=2)
        ttk.Button(button_frame, text="Change Password", 
                  command=self.change_password, style="Action.TButton").pack(fill="x", pady=2)
        ttk.Button(button_frame, text="Delete User", 
                  command=self.delete_user, style="Action.TButton").pack(fill="x", pady=2)

        # Search frame
        search_frame = ttk.Frame(self.window)
        search_frame.pack(fill="x", padx=10, pady=5)
        ttk.Label(search_frame, text="Search:").pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *args: self.filter_users())
        ttk.Entry(search_frame, textvariable=self.search_var).pack(side="left", fill="x", expand=True)

        # User listbox with scrollbar
        list_frame = ttk.Frame(self.window)
        list_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        self.user_listbox = tk.Listbox(list_frame, selectmode="single", font=('Arial', 10))
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.user_listbox.yview)
        self.user_listbox.configure(yscrollcommand=scrollbar.set)
        
        self.user_listbox.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def validate_username(self, username: str) -> bool:
        if not re.match("^[a-zA-Z0-9_]{3,20}$", username):
            messagebox.showerror("Error", "Username must be 3-20 characters long and contain only letters, numbers, and underscores.")
            return False
        return True

    def validate_password(self, password: str) -> bool:
        # This method in UserManager is already only checking for length, so no change needed.
        if len(password) < 8:
            messagebox.showerror("Error", "Password must be at least 8 characters long.")
            return False
        return True

    def save_user(self, username: str, hashed_pw: str, role: str) -> None:
        try:
            for row in self.ws.iter_rows(min_row=2):
                if row[0].value == username:
                    row[1].value = hashed_pw
                    row[2].value = role
                    break
            else:
                self.ws.append([username, hashed_pw, role])
            self.wb.save(self.db_path)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save user: {str(e)}")

    def get_users(self) -> List[Tuple[str, str]]:
        return [(row[0].value, row[2].value) for row in self.ws.iter_rows(min_row=2) 
                if row[0].value and row[2].value]

    def add_user(self) -> None:
        username = simpledialog.askstring("New User", "Username:")
        if not username or not self.validate_username(username):
            return

        password = simpledialog.askstring("New Password", "Password (min 8 chars):", show="*") # Updated label
        if not password or not self.validate_password(password): # validate_password only checks length
            return

        role = simpledialog.askstring("Role", "Role (admin/user):", 
                                    initialvalue="user")
        if not role or role.lower() not in ["admin", "user"]:
            messagebox.showerror("Error", "Invalid role. Must be 'admin' or 'user'.")
            return

        hashed_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        self.save_user(username.strip(), hashed_pw, role.strip().lower())
        messagebox.showinfo("Success", "User created or updated successfully.")
        self.refresh_user_list()

    def change_password(self) -> None:
        selected = self.user_listbox.curselection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a user first.")
            return
        
        username = self.user_listbox.get(selected[0]).split(" - ")[0]
        dialog = PasswordChangeDialog(self.window, username)
        self.window.wait_window(dialog)
        
        if dialog.result:
            current_pw, new_pw = dialog.result
            try:
                # Get current password hash
                current_hash = None
                for row in self.ws.iter_rows(min_row=2):
                    if row[0].value == username:
                        current_hash = row[1].value
                        break
                
                if not current_hash:
                    messagebox.showerror("Error", "User not found!")
                    return
                
                # Verify current password
                if not bcrypt.checkpw(current_pw.encode(), current_hash.encode()):
                    messagebox.showerror("Error", "Current password is incorrect!")
                    return
                
                # Hash and save new password
                hashed_pw = bcrypt.hashpw(new_pw.encode(), bcrypt.gensalt()).decode()
                self.save_user(username, hashed_pw, self.get_user_role(username))
                self.save_password_timestamp(username)
                
                messagebox.showinfo("Success", "Password changed successfully.")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to change password: {str(e)}")

    def delete_user(self) -> None:
        selected = self.user_listbox.curselection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a user first.")
            return

        username_to_delete = self.user_listbox.get(selected[0]).split(" - ")[0]

        # Require admin password for deletion
        admin_password_input = simpledialog.askstring("Admin Password Required", 
                                                       f"Enter password for admin to delete '{username_to_delete}':", 
                                                       show='*')
        if not admin_password_input:
            messagebox.showwarning("Deletion Cancelled", "Admin password not provided.")
            return

        # Authenticate admin
        admin_authenticated = False
        for row in self.ws.iter_rows(min_row=2):
            if row[0].value == "admin" and row[2].value == "admin":  # Assuming 'admin' is the admin username
                stored_admin_hash = row[1].value
                if bcrypt.checkpw(admin_password_input.encode(), stored_admin_hash.encode()):
                    admin_authenticated = True
                    break
        
        if not admin_authenticated:
            messagebox.showerror("Authentication Failed", "Incorrect admin password. Deletion not allowed.")
            return

        # Proceed with deletion if admin is authenticated
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete user {username_to_delete}? This action requires admin privileges and is irreversible."):
            rows_to_delete = []
            for idx, row in enumerate(self.ws.iter_rows(min_row=2), start=2):
                if row[0].value == username_to_delete:
                    rows_to_delete.append(idx)
            
            for row_idx in reversed(rows_to_delete):
                self.ws.delete_rows(row_idx)
            
            self.wb.save(self.db_path)
            self.refresh_user_list()
            messagebox.showinfo("Success", f"User '{username_to_delete}' deleted successfully.")

    def get_user_role(self, username: str) -> str:
        for row in self.ws.iter_rows(min_row=2):
            if row[0].value == username:
                return row[2].value
        return "user"

    def filter_users(self) -> None:
        search_text = self.search_var.get().lower()
        self.user_listbox.delete(0, tk.END)
        for username, role in self.get_users():
            if search_text in username.lower():
                self.user_listbox.insert(tk.END, f"{username} - {role}")

    def refresh_user_list(self) -> None:
        self.user_listbox.delete(0, tk.END)
        for username, role in self.get_users():
            self.user_listbox.insert(tk.END, f"{username} - {role}")

    def save_password_timestamp(self, username: str) -> None:
        timestamp_sheet_name = "PasswordHistory"
        if timestamp_sheet_name not in self.wb.sheetnames:
            ws = self.wb.create_sheet(timestamp_sheet_name)
            ws.append(["Username", "Changed_Date"])
        else:
            ws = self.wb[timestamp_sheet_name]

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for row in ws.iter_rows(min_row=2):
            if row[0].value == username:
                row[1].value = timestamp
                break
        else:
            ws.append([username, timestamp])

        self.wb.save(self.db_path)

def manage_users(db_path: str):
    """
    Function to create a new UserManager instance with debugging.
    """
    try:
        print(f"Attempting to open user management with database: {db_path}")
        if not db_path:
            raise ValueError("Database path is not specified")
            
        user_manager = UserManager(db_path)
        print("User management window created successfully")
        return user_manager
        
    except Exception as e:
        print(f"Error in manage_users: {str(e)}")
        messagebox.showerror("Error", f"Failed to open user management: {str(e)}")
        return None

# Example of how to use it (for testing purposes, if you run this script directly)
if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw() # Hide the main Tkinter window

    # Create a dummy Excel file for testing
    from openpyxl import Workbook
    import os
    test_db_path = "test_users.xlsx"
    
    # Remove existing test file to ensure clean start
    if os.path.exists(test_db_path):
        os.remove(test_db_path)

    wb_test = Workbook()
    ws_test = wb_test.active
    ws_test.title = "Users"
    ws_test.append(["Username", "Password_Hash", "Role"])
    
    # Add a default admin user for testing deletion and password changes
    # Ensure this password meets the *new* 8-char minimum
    admin_password = "AdminPassword" # Just 8 chars, no other complexity needed now
    hashed_admin_pw = bcrypt.hashpw(admin_password.encode(), bcrypt.gensalt()).decode()
    ws_test.append(["admin", hashed_admin_pw, "admin"])
    
    # Test user with a password that meets the new 8-char minimum
    testuser_password = "TestUserPW" # Just 8 chars
    hashed_testuser_pw = bcrypt.hashpw(testuser_password.encode(), bcrypt.gensalt()).decode()
    ws_test.append(["testuser", hashed_testuser_pw, "user"])
    wb_test.save(test_db_path)

    manager = manage_users(test_db_path)
    if manager:
        root.mainloop()