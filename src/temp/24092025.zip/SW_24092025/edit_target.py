
import tkinter as tk
from tkinter import ttk, messagebox
from openpyxl import load_workbook

def run(db_path):
    wb = load_workbook(db_path)
    if "Target" not in wb.sheetnames:
        messagebox.showerror("Erro", "A folha 'Target' não existe na base de dados.")
        return
    ws = wb["Target"]

    window = tk.Toplevel()
    window.title("Editar Targets")
    window.geometry("400x400")

    data = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if any(row):
            data.append([str(row[0]), str(row[1])])

    tree = ttk.Treeview(window, columns=["Audit Type", "Target"], show="headings")
    tree.heading("Audit Type", text="Audit Type")
    tree.heading("Target", text="Target")
    tree.pack(fill="both", expand=True, padx=10, pady=10)

    for item in data:
        tree.insert("", "end", values=item)

    form_frame = tk.Frame(window)
    form_frame.pack(pady=10)

    tk.Label(form_frame, text="Audit Type").grid(row=0, column=0, padx=5)
    audit_entry = tk.Entry(form_frame)
    audit_entry.grid(row=0, column=1, padx=5)

    tk.Label(form_frame, text="Target").grid(row=1, column=0, padx=5)
    target_entry = tk.Entry(form_frame)
    target_entry.grid(row=1, column=1, padx=5)

    def add_or_update():
        audit = audit_entry.get().strip()
        target = target_entry.get().strip()
        if not audit or not target:
            messagebox.showwarning("Aviso", "Preenche ambos os campos.")
            return
        for child in tree.get_children():
            values = tree.item(child)["values"]
            if values[0] == audit:
                tree.item(child, values=(audit, target))
                break
        else:
            tree.insert("", "end", values=(audit, target))
        audit_entry.delete(0, tk.END)
        target_entry.delete(0, tk.END)

    def delete_selected():
        selected = tree.selection()
        for item in selected:
            tree.delete(item)

    def save_changes():
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.value = None
        for i, item in enumerate(tree.get_children(), start=2):
            values = tree.item(item)["values"]
            ws.cell(row=i, column=1, value=values[0])
            ws.cell(row=i, column=2, value=values[1])
        wb.save(db_path)
        messagebox.showinfo("Sucesso", "Targets atualizados com sucesso.")
        window.destroy()

    tk.Button(window, text="Adicionar / Atualizar", command=add_or_update).pack(pady=2)
    tk.Button(window, text="Apagar Selecionado", command=delete_selected).pack(pady=2)
    tk.Button(window, text="Guardar", command=save_changes).pack(pady=10)
