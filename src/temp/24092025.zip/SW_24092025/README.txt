Audit Database Management System
Overview

This software is a comprehensive system designed to manage audit data. It provides functionalities for adding new audit samples, editing existing ones, visualizing data through various charts and KPIs, and robust user management with granular permission control. The application leverages an Excel file as its backend database, making it easy to set up and manage.
Features

    User Authentication: Secure login system with username and password.
    Role-Based Access Control: Different user roles (Admin, Auditor, Viewer) have specific permissions, ensuring data integrity and security. Permissions can be customized.
    New Sample Entry:
        Automatically generates unique IDs for new audit samples.
        Captures detailed information about each sample, including audit type, section, date, due date, decision date, and free-text descriptions.
        Validation for specific fields (e.g., TTNR format).
    Sample Editing & Deletion:
        Search and load existing audit samples by ID.
        Modify any field of an existing sample.
        Option to delete a sample after confirmation.
    Data Visualization (KPIs & Graphs):
        Interactive filtering of audit data based on various criteria.
        Generates key performance indicator (KPI) graphs:
            Radar Chart: Distribution of total samples and rejections (NOK) by section.
            Bar Chart: Monthly distribution of total samples and rejections, with an optional target line.
            Line Charts: Average response times (Decision Date - Date and Decision Date - Due Date) by month, showing efficiency.
        Displays monthly averages of samples and rejections, and overall average response times.
    Master Data Management:
        settings.py module allows administrators to manage predefined options for dropdowns (e.g., "Audit Type," "Section," "OK/NOK") directly within the application, ensuring consistency.
    User Management:
        user_management.py module for creating, updating, and deleting user accounts.
        permission_editor.py module for granting or revoking specific actions for each user (e.g., new_sample, edit_sample, settings, graphics, user_mgmt).
    Excel Backend: Uses .xlsx files for data storage, making the data accessible and manageable outside the application if needed.

Setup
Prerequisites

    Python 3.x
    Required Python libraries (install via pip):

    pip install openpyxl tkcalendar matplotlib bcrypt


Database Structure

The application expects a specific Excel file structure. The Excel file should contain the following sheets:

    Data Sheet:
        This sheet stores all the audit sample data.
        The first row must contain headers that the application uses to identify columns.
        Expected headers (case-sensitive and order matters for some operations):
            ID
            Day
            Month
            Year
            Date
            User
            Audit Type
            Section
            OK/NOK
            Due Date
            Decision Date
            Description
            Comments
            TTNR (specific format validation)
            (Other headers can be added as needed, but the application will primarily use the ones defined in the code)

    Options Sheet:
        This sheet stores the predefined values for dropdowns used in the "New Sample" and "Edit Sample" forms.
        The first row must contain headers corresponding to the Data sheet headers for which dropdowns are required (e.g., Audit Type, Section, OK/NOK).
        Each column under these headers should list the possible options.

    Users Sheet:
        This sheet stores user authentication information and roles.
        Headers: Username, Password_Hash, Role, Permissions
        Password_Hash stores bcrypt hashed passwords.
        Role defines the default role (e.g., admin, auditor, viewer).
        Permissions (optional): A comma-separated string of specific actions allowed for the user, overriding the default role permissions if present.

    Target Sheet (Optional, for KPI targets):
        This sheet can store target values for KPIs, specifically for the monthly distribution bar chart.
        Headers: Audit Type, Target
        Example: Internal Audit, 100

    PasswordHistory Sheet (Automatically created by User Management):
        Stores the last password change date for users.
        Headers: Username, Changed_Date

Running the Application

    Prepare your Excel Database:
        Create an Excel file (e.g., audit_database.xlsx).
        Create the Data, Options, Users, and Target sheets with the specified headers.
        Populate the Options sheet with your desired dropdown values.
        Populate the Users sheet with at least one admin user. You can use the User Management module after initial login to add more users.

    Run the Main Application:

    python main.py


    Select Database: Click "Select Database" and choose your prepared Excel file.

    Login: Use a valid username and password from your Users sheet.

Modules

The application is structured into several modules:

    main.py: The entry point of the application, handles database selection, login, and launching the main interface based on user permissions.
    login.py: Manages user authentication against the Users sheet.
    user_management.py: Provides administrative functions for adding, updating, and deleting user accounts, including password changes.
    permission_editor.py: Allows administrators to assign granular permissions to individual users.
    permissions.py: Defines default role permissions and retrieves custom user permissions.
    new_sample.py: Interface for creating and saving new audit samples to the Data sheet.
    edit_sample.py: Interface for loading, editing, and deleting existing audit samples.
    graphics.py: Module for data visualization, including filters, tables, and KPI charts.
    edit_target.py: Allows modification of target values in the Target sheet.
    settings.py: Provides an interface for managing predefined options in the Options sheet.

How to Use

    Start the Application: Run main.py.
    Select your Excel Database: Use the "Select Database" button.
    Login: Enter your credentials. An admin user is typically set up manually in the Excel Users sheet initially.
    Navigate: Based on your user's permissions, you will see buttons for different functionalities:
        New Sample: To record a new audit.
        Edit Sample: To modify or delete an existing audit record.
        Database Info: To view and analyze data through filters and KPIs.
        Settings: (Admin only) To manage dropdown options.
        User Management: (Admin only) To add/update/delete users and change passwords.
        Access Edit: (Admin only) To customize user permissions.
    Logout: Return to the login screen.

Development Notes

    Error Handling: Basic error handling is implemented with messagebox for user feedback.
    Security: Passwords are stored as bcrypt hashes. The application relies on the security of the underlying Excel file and the operating system's file permissions.
    Extensibility: New features or data fields can be added by modifying the Excel sheet headers and updating the corresponding Python code in new_sample.py, edit_sample.py, and graphics.py.
    Data Validation: Some fields have built-in validation (e.g., TTNR format). Further validation can be added as needed.
