import datetime
import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
from openpyxl import load_workbook, Workbook
import re
import os # Importar a biblioteca os

def run(db_path, current_user):

    def get_options_dict(sheet):
        options = {}
        headers = [cell.value for cell in sheet[1]]
        for header in headers:
            options[header] = []
        for row in sheet.iter_rows(min_row=2, values_only=True):
            for i, header in enumerate(headers):
                if i < len(row) and row[i] and row[i] not in options[header]:
                    options[header].append(row[i])
        return options

    def get_next_id(sheet, desired_year):
        prefix = f"{desired_year}-"
        existing_numbers = []
        for row_index in range(2, sheet.max_row + 1):
            cell_value = sheet.cell(row=row_index, column=1).value
            if isinstance(cell_value, str) and cell_value.startswith(prefix):
                try:
                    numeric_part = int(cell_value.split('-')[1])
                    existing_numbers.append(numeric_part)
                except (ValueError, IndexError):
                    print(f"Warning: Skipping malformed ID: {cell_value}")
                    continue

        if existing_numbers:
            next_number = max(existing_numbers) + 1
        else:
            next_number = 1

        return f"{prefix}{next_number:05d}"

    def submit():
        try:
            wb_submit = load_workbook(db_path)
            data_ws_submit = wb_submit["Data"]

            selected_date = date_entry.get_date()
            id_year_from_date_entry = selected_date.year

            new_id = get_next_id(data_ws_submit, id_year_from_date_entry)
            id_var.set(new_id)

            values = {}
            values["ID"] = new_id
            values["Date"] = selected_date.strftime("%d/%m/%Y")
            values["Day"] = selected_date.day
            values["Month"] = selected_date.month
            values["Year"] = selected_date.year
            values["User"] = current_user

            for header in data_headers:
                if header in ["ID", "Day", "Month", "Year", "Date", "User"]:
                    continue
                widget_entry = widgets.get(header) # Get the entry widget reference

                if widget_entry is None:
                    print(f"Widget not found for header: {header}")
                    continue

                if header in ["Due Date", "Decision Date"]:
                    date_str = widget_entry.get()
                    if date_str.strip(): # Check if the string is not just whitespace
                        try:
                            # Parse and reformat to ensure consistent format if user typed manually
                            values[header] = datetime.datetime.strptime(date_str, "%d/%m/%Y").strftime("%d/%m/%Y")
                        except ValueError:
                            messagebox.showerror("Invalid Date", f"Please enter a valid date for '{header}' in DD/MM/YYYY format, or leave it empty.")
                            return # Stop submission if date is invalid
                    else:
                        values[header] = "" # Store as empty string if cleared
                # Agora TTNR também é um Text widget
                elif header in ["Comments", "Description", "TTNR"]:
                    values[header] = widget_entry.get("1.0", tk.END).strip()
                elif isinstance(widget_entry, ttk.Combobox) or isinstance(widget_entry, tk.Entry):
                    values[header] = widget_entry.get()


            # Nova validação para TTNR
            ttnr_references = [] # Lista para armazenar as referências TTNR válidas
            if "TTNR" in values and values["TTNR"]:
                ttnr_text = values["TTNR"]
                # Divide o texto por quebras de linha e filtra linhas vazias
                ttnr_lines = [line.strip() for line in ttnr_text.split('\n') if line.strip()]
                
                # Regex para um único formato TTNR
                ttnr_regex = r"^\d-\d{3}-\d{3}-\d{3}$"
                
                # Verifica cada linha
                for line in ttnr_lines:
                    if not re.fullmatch(ttnr_regex, line):
                        messagebox.showerror("Error", f"Invalid TTNR format found: '{line}'. Each TTNR must be: x-xxx-xxx-xxx")
                        return
                    ttnr_references.append(line) # Adiciona à lista de referências válidas

            new_row = [values.get(header, "") for header in data_headers]
            data_ws_submit.append(new_row)
            wb_submit.save(db_path)

            # --- Adição da lógica de criação de pastas ---
            base_folder_path = "H:/QMM/QMM1/02_ISIR/1. ISIR_A-TEST_Tracker/Test_Data"
            
            # 1. Cria a pasta com o ID (YYYY-XXXXX)
            id_folder_path = os.path.join(base_folder_path, new_id)
            try:
                os.makedirs(id_folder_path, exist_ok=True) # exist_ok=True evita erro se a pasta já existir
                print(f"Pasta principal criada para ID '{new_id}': {id_folder_path}")
            except OSError as e:
                messagebox.showerror("Error", f"Failed to create folder for ID '{new_id}': {e}")
                # Decide se queres continuar ou sair aqui
                # Por agora, vamos continuar, mas é um ponto a considerar

            # 2. Cria as subpastas para cada referência TTNR
            if ttnr_references:
                for ttnr_ref in ttnr_references:
                    ttnr_folder_path = os.path.join(id_folder_path, ttnr_ref)
                    try:
                        os.makedirs(ttnr_folder_path, exist_ok=True)
                        print(f"Subpasta TTNR criada: {ttnr_folder_path}")
                    except OSError as e:
                        messagebox.showerror("Error", f"Failed to create subfolder for TTNR '{ttnr_ref}' in '{new_id}': {e}")
                        # Novamente, decide o comportamento em caso de erro
            # --- Fim da adição da lógica de criação de pastas ---


            messagebox.showinfo("Success", f"New sample saved successfully.\nSample ID: {new_id}\nFolders created.")
            window.destroy()

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
            print(f"Error details: {e}")

    # Load initial workbook data for setup
    try:
        wb = load_workbook(db_path)
        data_ws = wb["Data"]
        options_ws = wb["Options"]
    except FileNotFoundError:
        messagebox.showerror("Error", f"Database file not found at {db_path}")
        return
    except KeyError as e:
        messagebox.showerror("Error", f"Required sheet not found in workbook: {e}")
        return
    except Exception as e:
        messagebox.showerror("Error", f"Error loading workbook: {e}")
        return

    data_headers = [cell.value for cell in data_ws[1]]
    options_headers = [cell.value for cell in options_ws[1]]
    options = get_options_dict(options_ws)

    # Tkinter window setup
    window = tk.Toplevel()
    window.title("New Sample")
    window.geometry("1080x1080")

    # Main frame for padding
    main_frame = tk.Frame(window)
    main_frame.pack(fill=tk.BOTH, expand=1, padx=10, pady=10)

    # Canvas for scrollability
    canvas = tk.Canvas(main_frame)
    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=1)

    # Scrollbar
    scrollbar = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=canvas.yview)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # Configure canvas and bind to scrollbar
    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

    # Frame inside the canvas where all widgets will be placed
    frame = tk.Frame(canvas, padx=20, pady=20)
    canvas.create_window((0, 0), window=frame, anchor="nw")

    def _on_mousewheel(event):
        canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    canvas.bind_all("<MouseWheel>", _on_mousewheel)

    widgets = {} # Dictionary to store references to created widgets

    style = ttk.Style()
    style.configure('Header.TLabel', font=('Helvetica', 10, 'bold'))
    style.configure('Section.TFrame', padding=10)

    # Basic Information Section
    basic_info_frame = ttk.LabelFrame(frame, text="Basic Information", padding=10)
    basic_info_frame.grid(row=0, column=0, columnspan=2, sticky='ew', pady=(0, 20))

    ttk.Label(basic_info_frame, text="ID:").grid(row=0, column=0, sticky='e', padx=5, pady=5)
    id_var = tk.StringVar(value="(Auto-generated)")
    id_entry = tk.Entry(basic_info_frame, textvariable=id_var, state="readonly")
    id_entry.grid(row=0, column=1, sticky='w', padx=5, pady=5)

    ttk.Label(basic_info_frame, text="Date:").grid(row=1, column=0, sticky='e', padx=5, pady=5)
    date_entry = DateEntry(basic_info_frame, date_pattern="dd/mm/yyyy", locale="pt_PT")
    date_entry.grid(row=1, column=1, sticky='w', padx=5, pady=5)

    # Other fields (dynamic creation)
    current_row = 2

    # Campos que devem ser Text Widgets com scroll (agora incluindo "TTNR")
    text_widget_headers = ["Description", "Comments", "TTNR"]

    for header in data_headers:
        if header in ["ID", "Day", "Month", "Year", "Date", "User"]:
            continue

        ttk.Label(frame, text=f"{header}:", style='Header.TLabel').grid(
            row=current_row, column=0, sticky='ne', padx=5, pady=(10, 2))

        if header in text_widget_headers:
            # Create a sub-frame to hold the Text widget and its scrollbar
            text_field_frame = tk.Frame(frame)
            text_field_frame.grid(row=current_row, column=1, sticky='ew', padx=5, pady=(10, 2))

            # Define o height inicial. Para TTNR queremos 4 linhas. Para Description/Comments, 5.
            initial_height = 4 if header == "TTNR" else 5
            widget = tk.Text(text_field_frame, height=initial_height, wrap="word")
            widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

            # Create a scrollbar for the Text widget
            text_scrollbar = ttk.Scrollbar(text_field_frame, orient=tk.VERTICAL, command=widget.yview)
            text_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

            # Link the Text widget to the scrollbar
            widget.config(yscrollcommand=text_scrollbar.set)
            widgets[header] = widget

        elif header in ["Due Date", "Decision Date"]:
            # Create a sub-frame to hold the DateEntry and the Clear button
            date_frame = tk.Frame(frame)
            date_frame.grid(row=current_row, column=1, sticky='ew', padx=5, pady=(10, 2))
            
            widget = DateEntry(
                date_frame, # Place it in the date_frame
                date_pattern="dd/mm/yyyy",
                locale="pt_PT",
                selectmode='day',
                background='darkblue',
                foreground='white',
                borderwidth=2,
                state='normal' # Ensure it's editable
            )
            widget.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5)) # Pack it to the left

            # Define a clear function for this specific DateEntry
            def clear_date_entry(entry_widget):
                entry_widget.delete(0, tk.END)

            clear_button = ttk.Button(date_frame, text="Clear", command=lambda w=widget: clear_date_entry(w))
            clear_button.pack(side=tk.RIGHT)

            widgets[header] = widget

        elif header in options_headers:
            widget = ttk.Combobox(frame, values=options[header], state="readonly", width=30)
            widget.grid(row=current_row, column=1, sticky='ew', padx=5, pady=(10, 2))

        else: # Default to Entry field (no longer includes TTNR)
            widget = ttk.Entry(frame, width=32)
            widget.grid(row=current_row, column=1, sticky='ew', padx=5, pady=(10, 2))

        # Store widget reference (já feito no bloco text_widget_headers)
        if header not in text_widget_headers and header not in ["Due Date", "Decision Date"]: # Ensure all widgets are stored
            widgets[header] = widget

        current_row += 1

    # Save button
    save_frame = ttk.Frame(frame)
    save_frame.grid(row=current_row, column=0, columnspan=2, pady=20)
    save_button = ttk.Button(save_frame, text="Save", command=submit)
    save_button.pack()

    # Configure grid columns to expand with window resizing
    frame.grid_columnconfigure(1, weight=1)

    window.mainloop()
