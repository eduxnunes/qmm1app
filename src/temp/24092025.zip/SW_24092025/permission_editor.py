
import tkinter as tk
from tkinter import messagebox
from openpyxl import load_workbook

ALL_ACTIONS = ["new_sample", "edit_sample", "settings", "graphics", "user_mgmt"]

def edit_permissions(db_path):
    wb = load_workbook(db_path)
    if "Users" not in wb.sheetnames:
        messagebox.showerror("Erro", "A folha 'Users' não existe.")
        return
    ws = wb["Users"]

    users_data = []
    for i, row in enumerate(ws.iter_rows(min_row=2), start=2):
        username = row[0].value
        permissions = row[3].value if len(row) > 3 and row[3].value else ""
        users_data.append((i, username, permissions.split(",") if permissions else []))

    win = tk.Toplevel()
    win.title("Editor de Permissões")
    win.geometry("500x400")

    user_var = tk.StringVar()
    check_vars = {action: tk.IntVar() for action in ALL_ACTIONS}

    def load_permissions(*args):
        selected_user = user_var.get()
        for idx, username, perms in users_data:
            if username == selected_user:
                for action in ALL_ACTIONS:
                    check_vars[action].set(1 if action in perms else 0)
                break

    def save_permissions():
        selected_user = user_var.get()
        for idx, username, perms in users_data:
            if username == selected_user:
                new_perms = [act for act in ALL_ACTIONS if check_vars[act].get()]
                ws.cell(row=idx, column=4, value=",".join(new_perms))
                wb.save(db_path)
                messagebox.showinfo("Sucesso", f"Permissões guardadas para {selected_user}")
                return

    tk.Label(win, text="Selecionar Utilizador").pack(pady=5)
    usernames = [u for _, u, _ in users_data]
    user_menu = tk.OptionMenu(win, user_var, *usernames)
    user_menu.pack()

    user_var.trace("w", load_permissions)

    frame = tk.Frame(win)
    frame.pack(pady=10)
    for i, action in enumerate(ALL_ACTIONS):
        tk.Checkbutton(frame, text=action, variable=check_vars[action]).grid(row=i // 2, column=i % 2, sticky="w", padx=10, pady=2)

    tk.Button(win, text="Guardar Permissões", command=save_permissions).pack(pady=10)
